# Instagram downloader setup

The `.instagram`, `.igs`, and `.igsc` commands now use the shared resolver in `utils/instagramApi.js`.

The resolver races the configured provider, the optional RapidAPI provider, the maintained JerryCoder provider, and a direct public-page fallback. Results are cached briefly and identical requests share one in-flight request. The deprecated `ruhend-scraper` path is disabled by default because it can take too long; enable it only as a last-resort compatibility fallback with `INSTAGRAM_ENABLE_LEGACY_SCRAPER=true`.

For the most reliable production behavior, configure a RapidAPI key for the documented Instagram Downloader endpoint:

```env
INSTAGRAM_RAPIDAPI_KEY=your_rapidapi_key
```

Other optional settings are:

```env
# A self-hosted or private provider. Supports GET ?url=... by default.
INSTAGRAM_API_URL=https://your-provider.example/instagram
INSTAGRAM_API_METHOD=GET

# Provider request limit, clamped to 5–10 seconds.
INSTAGRAM_API_TIMEOUT_MS=7000

# Only if you explicitly want the deprecated compatibility scraper.
INSTAGRAM_ENABLE_LEGACY_SCRAPER=false

# Group moderation preflight limit before a command is allowed to continue.
JUNE_MODERATION_PREFLIGHT_TIMEOUT_MS=700
```

Private Instagram posts and links blocked by Instagram cannot be downloaded without an authenticated provider. The bot now fails those requests quickly instead of waiting through the old long retry path.
