const test = require("node:test");
const assert = require("node:assert/strict");
const { extractInstagramUrl, normalizeMedia } = require("../utils/instagramApi");

test("extracts Instagram links from command text", () => {
  assert.equal(
    extractInstagramUrl(".ig https://www.instagram.com/reel/ABC123/?utm_source=x."),
    "https://www.instagram.com/reel/ABC123/?utm_source=x"
  );
  assert.equal(extractInstagramUrl("no link here"), null);
});

test("normalizes common provider response shapes and removes duplicates", () => {
  const media = normalizeMedia({
    data: [
      { downloadUrl: "https://cdn.example/video.mp4", type: "video" },
      { url: "https://cdn.example/photo.jpg" },
      { url: "https://cdn.example/video.mp4" }
    ]
  });
  assert.deepEqual(media.map(item => ({ url: item.url, type: item.type })), [
    { url: "https://cdn.example/video.mp4", type: "video" },
    { url: "https://cdn.example/photo.jpg", type: "image" }
  ]);
});

test("normalizes nested URL arrays", () => {
  const media = normalizeMedia({ result: { urls: ["https://cdn.example/a.jpg", "https://cdn.example/b.mp4"] } });
  assert.equal(media.length, 2);
  assert.equal(media[1].type, "video");
});
