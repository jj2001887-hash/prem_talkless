const assert = require("assert");
const fs = require("fs");
const path = require("path");
const movies = require("../commands/movies/movie");
const musicVideo = require("../commands/media/musicvideo");
const video = require("../commands/media/video");
const song = require("../commands/media/song");
const movieApi = require("../utils/movieApi");
const youtubeMedia = require("../utils/youtubeMedia");

const movieList = Array.isArray(movies) ? movies : [movies];
const names = new Set(movieList.map(command => command.name));
for (const name of ["moviesearch", "moviedetail", "moviebox", "watchmovie", "moviedownload", "trailer", "moviedl", "tvsearch", "animesearch"]) {
  assert.ok(names.has(name), `missing movie command: ${name}`);
}
assert.strictEqual(musicVideo.name, "musicvideo");
assert.ok(musicVideo.aliases.includes("mv"));
assert.strictEqual(video.name, "ytvideo");
assert.strictEqual(song.name, "play");

const movieSource = fs.readFileSync(path.join(__dirname, "..", "commands", "movies", "movie.js"), "utf8");
assert.doesNotMatch(movieSource, /apiskeith|railway\.app|downloadUrl/);
const movieApiSource = fs.readFileSync(path.join(__dirname, "..", "utils", "movieApi.js"), "utf8");
assert.match(movieApiSource, /api\.themoviedb\.org/);
assert.match(movieApiSource, /api\.tvmaze\.com/);
assert.match(movieApiSource, /media-imdb\.com/);
assert.match(movieApiSource, /yt-search/);
assert.match(movieApiSource, /watch\/providers/);
const mediaSource = fs.readFileSync(path.join(__dirname, "..", "utils", "youtubeMedia.js"), "utf8");
assert.match(mediaSource, /yt-dlp-exec/);
assert.match(mediaSource, /audioFormat = "mp3"/);
assert.match(mediaSource, /mergeOutputFormat = "mp4"/);

assert.match(movieApi.formatResults([{ title: "Test Movie", year: "2026", rating: "8.0", url: "https://example.com" }], "Movie search"), /Test Movie/);
assert.match(movieApi.formatDetails({ title: "Test Movie", year: "2026", rating: "8.0", overview: "A test overview." }), /> BY TALKLESS/);
assert.strictEqual(typeof youtubeMedia.resolveYtDlpBinary, "function");
console.log("MOVIES/MEDIA TEST: all assertions passed");
