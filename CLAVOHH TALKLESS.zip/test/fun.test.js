'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { loadCommands } = require('../utils/commandLoader');
const funApi = require('../utils/funApi');

const funDir = path.join(__dirname, '..', 'commands', 'fun');
const sourceFiles = fs.readdirSync(funDir).filter(file => file.endsWith('.js'));
for (const file of sourceFiles) {
  assert.doesNotThrow(() => require(path.join(funDir, file)), `fun command failed to load: ${file}`);
}

const commands = loadCommands();
for (const name of ['fact', 'quotes', 'flirt', 'pickupline', 'paranoia', 'wyr', 'memesearch', 'pies', 'question', 'joke', 'meme', 'tictactoe']) {
  assert.ok(commands.has(name), `missing fun command: ${name}`);
}

const changedFiles = ['fact.js', 'quote.js', 'flirt.js', 'pickupline.js', 'paranoia.js', 'wyr.js', 'memesearch.js', 'pies.js'];
for (const file of changedFiles) {
  const source = fs.readFileSync(path.join(funDir, file), 'utf8');
  assert.doesNotMatch(source, /api\.shizo\.top/);
}

for (const key of ['facts', 'quotes', 'flirt', 'pickup', 'paranoia', 'wyr']) {
  assert.ok(Array.isArray(funApi._data[key]) && funApi._data[key].length > 0, `missing local ${key} fallback`);
}
assert.strictEqual(typeof funApi.randomFact, 'function');
assert.strictEqual(typeof funApi.randomQuote, 'function');
assert.strictEqual(typeof funApi.randomWouldYouRather, 'function');

console.log('FUN TEST: all assertions passed');
