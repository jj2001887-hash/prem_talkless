const assert = require("assert");
const restart = require("../commands/owner/restart");

const saved = {
  restartRequested: global._restartRequested,
  shutdown: global.__JUNE_SHUTDOWN,
  setTimeout,
  exit: process.exit
};

(async () => {
  const replies = [];
  const exits = [];
  let gracefulCalls = 0;
  let scheduled = null;

  global._restartRequested = false;
  global.__JUNE_SHUTDOWN = async () => {
    gracefulCalls += 1;
  };
  global.setTimeout = callback => {
    scheduled = callback;
    return 1;
  };
  process.exit = code => exits.push(code);

  await restart.execute(null, null, null, {
    reply: async message => replies.push(message)
  });

  assert.strictEqual(global._restartRequested, true, "restart should be marked as requested");
  assert.strictEqual(replies.length, 1, "restart should send one scheduling reply");
  assert.match(replies[0], /Restart scheduled/);
  assert.match(replies[0], /> BY TALKLESS/);
  assert.strictEqual(typeof scheduled, "function", "restart should schedule deferred cleanup");

  await restart.execute(null, null, null, {
    reply: async message => replies.push(message)
  });
  assert.strictEqual(replies.length, 2, "duplicate restart should receive a status reply");
  assert.match(replies[1], /already scheduled/);

  await scheduled();
  assert.strictEqual(gracefulCalls, 1, "restart should call the graceful shutdown routine once");
  assert.deepStrictEqual(exits, [restart.RESTART_EXIT_CODE], "restart should exit with supervisor restart code");

  global._restartRequested = saved.restartRequested;
  global.__JUNE_SHUTDOWN = saved.shutdown;
  global.setTimeout = saved.setTimeout;
  process.exit = saved.exit;
  console.log("RESTART TEST: all assertions passed");
})().catch(error => {
  global._restartRequested = saved.restartRequested;
  global.__JUNE_SHUTDOWN = saved.shutdown;
  global.setTimeout = saved.setTimeout;
  process.exit = saved.exit;
  console.error("RESTART TEST FAILED:", error);
  process.exitCode = 1;
});
