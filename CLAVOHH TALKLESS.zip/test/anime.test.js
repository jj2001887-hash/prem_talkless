const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { formatAnime, sendAnimeError } = require("../utils/animeApi");

const animeDir = path.join(__dirname, "..", "commands", "anime");
const commandNames = new Set();
for (const file of fs.readdirSync(animeDir).filter(file => file.endsWith(".js"))) {
  const loaded = require(path.join(animeDir, file));
  for (const command of Array.isArray(loaded) ? loaded : [loaded]) {
    assert.ok(command.name, `${file} must expose a command name`);
    assert.strictEqual(typeof command.execute, "function", `${command.name} must expose execute()`);
    commandNames.add(command.name);
  }
}

for (const name of ["waifu", "neko", "loli", "shota", "husby", "hwaifu", "hneko", "megumin", "milf", "konachan", "random"]) {
  assert.ok(commandNames.has(name), `missing anime command: ${name}`);
}

const source = fs.readFileSync(path.join(__dirname, "..", "utils", "animeApi.js"), "utf8");
assert.match(source, /api\.waifu\.im/);
assert.match(source, /api\.waifu\.pics/);
assert.match(source, /api\.jikan\.moe/);
assert.match(source, /graphql\.anilist\.co/);
for (const file of fs.readdirSync(animeDir).filter(file => file.endsWith(".js"))) {
  const contents = fs.readFileSync(path.join(animeDir, file), "utf8");
  assert.doesNotMatch(contents, /princetechn|api\.shizo\.top|apikey=prince|apikey=shizo/);
}

const formatted = formatAnime({
  title: "Cowboy Bebop",
  episodes: 26,
  status: "Finished Airing",
  score: 8.8,
  year: 1998,
  genres: ["Action", "Sci-Fi"],
  synopsis: "A space bounty hunter story.",
  url: "https://example.com/anime/1"
});
assert.match(formatted, /Cowboy Bebop/);
assert.match(formatted, /Episodes: 26/);
assert.match(formatted, /> BY TALKLESS/);

(async () => {
  let reply = "";
  await sendAnimeError({ reply: async text => { reply = text; } }, "smoke", new Error("provider detail must stay hidden"));
  assert.match(reply, /Anime service unavailable/);
  assert.doesNotMatch(reply, /provider detail/);
  console.log("ANIME TEST: all assertions passed");
})().catch(error => {
  console.error("ANIME TEST FAILED:", error);
  process.exitCode = 1;
});
