const guessGames = new Map();
const hangmanGames = new Map();
const WORDS = ["football", "tetris", "whatsapp", "javascript", "champion", "keyboard", "rainbow", "elephant", "mountain", "computer"];
const CHOICES = ["rock", "paper", "scissors"];

function footer(text) {
  return text + "\n\n> BY TALKLESS";
}

function chatId(command, msg) {
  return command.from || msg?.key?.remoteJid || "global";
}

function guessStatus(game) {
  return "🎯 *NUMBER GUESS*\n\nGuess a number from *1 to 100*.\n❤️ Attempts left: *" + game.attempts + "*\n\nUse *.guess 1-100* or *.guess new* to restart.";
}

function hangmanStatus(game) {
  const masked = [...game.word].map(letter => game.guessed.has(letter) ? letter.toUpperCase() : "_ ").join("");
  return "🔤 *HANGMAN*\n\nWord: *" + masked + "*\n💡 Wrong guesses: " + (game.wrong.length ? game.wrong.join(", ") : "none") + "\n❤️ Attempts left: *" + (6 - game.wrong.length) + "*\n\nSend one letter or the full word. Use *.hangman new* to restart.";
}

module.exports = [{
  name: "rps",
  aliases: ["rockpaperscissors", "rockpaper"] ,
  category: "games",
  description: "Play Rock Paper Scissors",
  usage: ".rps <rock|paper|scissors>",
  async execute(sock, msg, args, command) {
    const input = String(args[0] || "").toLowerCase();
    if (!CHOICES.includes(input)) {
      return command.reply(footer("🪨 *ROCK PAPER SCISSORS*\n\nChoose one: *rock*, *paper*, or *scissors*.\n\nExample: *.rps rock*"));
    }
    const bot = CHOICES[Math.floor(Math.random() * CHOICES.length)];
    const win = input === bot || input === "rock" && bot === "scissors" || input === "paper" && bot === "rock" || input === "scissors" && bot === "paper";
    const result = input === bot ? "🤝 Draw" : win ? "🏆 You win" : "🤖 Bot wins";
    await command.reply(footer("🪨 *ROCK PAPER SCISSORS*\n\n👤 You: *" + input + "*\n🤖 Bot: *" + bot + "*\n\n" + result));
  }
}, {
  name: "guess",
  aliases: ["numberguess", "guessnumber"],
  category: "games",
  description: "Guess the bot's secret number from 1 to 100",
  usage: ".guess <number|new>",
  async execute(sock, msg, args, command) {
    const id = chatId(command, msg);
    const input = String(args[0] || "").toLowerCase();
    if (!guessGames.has(id) || input === "new" || input === "start") {
      guessGames.set(id, { number: Math.floor(Math.random() * 100) + 1, attempts: 7 });
      return command.reply(footer("🎯 *NUMBER GUESS STARTED*\n\nI picked a number from *1 to 100*.\nYou have *7 attempts*.\n\nSend *.guess number* to play."));
    }
    const game = guessGames.get(id);
    const number = Number(input);
    if (!Number.isInteger(number) || number < 1 || number > 100) {
      return command.reply(footer("❌ Enter a whole number from *1 to 100*.\n\n" + guessStatus(game)));
    }
    game.attempts--;
    if (number === game.number) {
      guessGames.delete(id);
      return command.reply(footer("🎉 *CORRECT!*\n\nThe number was *" + game.number + "*.\nYou won with *" + game.attempts + " attempts left*."));
    }
    if (game.attempts <= 0) {
      guessGames.delete(id);
      return command.reply(footer("💔 *GAME OVER*\n\nThe number was *" + game.number + "*.\nUse *.guess new* to play again."));
    }
    const hint = number < game.number ? "Try a higher number." : "Try a lower number.";
    await command.reply(footer("❌ Not correct. " + hint + "\n\n" + guessStatus(game)));
  }
}, {
  name: "hangman",
  aliases: ["wordguess", "wordgame"],
  category: "games",
  description: "Play Hangman with a hidden word",
  usage: ".hangman [letter|word|new]",
  async execute(sock, msg, args, command) {
    const id = chatId(command, msg);
    const input = String(args.join(" ") || "").toLowerCase().replace(/[^a-z]/g, "");
    if (!hangmanGames.has(id) || input === "new" || input === "start") {
      const word = WORDS[Math.floor(Math.random() * WORDS.length)];
      hangmanGames.set(id, { word, guessed: new Set(), wrong: [] });
      return command.reply(footer("🔤 *HANGMAN STARTED*\n\n" + hangmanStatus(hangmanGames.get(id))));
    }
    const game = hangmanGames.get(id);
    if (!input) {
      return command.reply(footer(hangmanStatus(game)));
    }
    if (input.length > 1) {
      if (input === game.word) {
        hangmanGames.delete(id);
        return command.reply(footer("🎉 *YOU WON!*\n\nThe word was *" + game.word.toUpperCase() + "*."));
      }
      if (!game.wrong.includes(input)) game.wrong.push(input);
    } else if (game.word.includes(input)) {
      game.guessed.add(input);
    } else if (!game.wrong.includes(input)) {
      game.wrong.push(input);
    }
    if ([...game.word].every(letter => game.guessed.has(letter))) {
      hangmanGames.delete(id);
      return command.reply(footer("🎉 *YOU WON!*\n\nThe word was *" + game.word.toUpperCase() + "*."));
    }
    if (game.wrong.length >= 6) {
      hangmanGames.delete(id);
      return command.reply(footer("💔 *GAME OVER*\n\nThe word was *" + game.word.toUpperCase() + "*.\nUse *.hangman new* to try again."));
    }
    await command.reply(footer(hangmanStatus(game)));
  }
}, {
  name: "gamehelp",
  aliases: ["gameshelp", "gamelist"],
  category: "games",
  description: "Show playable text games",
  usage: ".gamehelp",
  async execute(sock, msg, args, command) {
    await command.reply(footer("🎮 *TALKLESS GAMES*\n\n✰ *.rps rock* — Rock Paper Scissors\n✰ *.guess new* — Guess a number from 1 to 100\n✰ *.hangman new* — Guess the hidden word\n✰ *.snake* — Play Snake\n✰ *.tetris* — Play Tetris"));
  }
}];
