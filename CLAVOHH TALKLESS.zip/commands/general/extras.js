const os = require("os");

function footer(text) {
  return text + "\n\n> BY TALKLESS";
}

function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor(seconds % 86400 / 3600);
  const minutes = Math.floor(seconds % 3600 / 60);
  const secs = seconds % 60;
  return [days ? days + "d" : "", hours ? hours + "h" : "", minutes ? minutes + "m" : "", secs + "s"].filter(Boolean).join(" ");
}

module.exports = [{
  name: "serverinfo",
  aliases: ["sysinfo", "hostinfo"],
  category: "general",
  description: "Show bot server and runtime information",
  usage: ".serverinfo",
  async execute(sock, msg, args, command) {
    const memory = process.memoryUsage();
    const text = [
      "🖥️ *SERVER INFO*",
      "",
      "⚙️ *Platform:* " + os.platform() + " " + os.arch(),
      "🧩 *Node.js:* " + process.version,
      "⏱️ *Uptime:* " + formatUptime(Math.floor(process.uptime())),
      "💾 *Memory:* " + (memory.rss / 1024 / 1024).toFixed(1) + " MB RSS",
      "🧠 *CPU:* " + os.cpus().length + " cores",
      "🌍 *Hostname:* " + os.hostname()
    ].join("\n");
    await command.reply(footer(text));
  }
}, {
  name: "timestamp",
  aliases: ["unix", "epoch"],
  category: "general",
  description: "Convert a date or timestamp to Unix time",
  usage: ".timestamp [date or Unix timestamp]",
  async execute(sock, msg, args, command) {
    const input = args.join(" ").trim();
    let date;
    if (!input) {
      date = new Date();
    } else if (/^\d{10,13}$/.test(input)) {
      const number = Number(input);
      date = new Date(input.length === 10 ? number * 1000 : number);
    } else {
      date = new Date(input);
    }
    if (Number.isNaN(date.getTime())) {
      return command.reply(footer("❌ Invalid date.\n\nExample: *.timestamp 2026-11-26 12:30*"));
    }
    const seconds = Math.floor(date.getTime() / 1000);
    await command.reply(footer("🕒 *TIMESTAMP*\n\n📅 *Date:* " + date.toISOString() + "\n🔢 *Unix:* `" + seconds + "`\n⏱️ *WhatsApp format:* `" + date.toISOString().replace(/\.\d{3}Z$/, "Z") + "`"));
  }
}, {
  name: "randomnumber",
  aliases: ["randnum", "randomnum"],
  category: "general",
  description: "Generate a random number in a range",
  usage: ".randomnumber [minimum] [maximum]",
  async execute(sock, msg, args, command) {
    const min = args.length ? Number(args[0]) : 1;
    const max = args.length > 1 ? Number(args[1]) : 100;
    if (!Number.isSafeInteger(min) || !Number.isSafeInteger(max) || min > max || max - min > 1000000000) {
      return command.reply(footer("❌ Use whole numbers with a valid range.\n\nExample: *.randomnumber 1 50*"));
    }
    const result = min + Math.floor(Math.random() * (max - min + 1));
    await command.reply(footer("🎲 *RANDOM NUMBER*\n\n🔢 Range: `" + min + " – " + max + "`\n✅ Result: *" + result + "*"));
  }
}];
