const {
  loadCommands
} = require("../../utils/commandLoader");
const {
  sendButtons
} = require("gifted-btns");
const {
  applyFont
} = require("../../utils/fontConverter");
const fs = require("fs");
const path = require("path");
const os = require("os");
const db = require("../../database");
let menuImageIndex = 0;
const detectPlatform = () => {
  return "🌍 Heroku";
};
function formatUptime() {
  const value9 = Math.floor(process.uptime());
  const value10 = Math.floor(value9 / 86400);
  const value11 = Math.floor(value9 % 86400 / 3600);
  const value12 = Math.floor(value9 % 3600 / 60);
  const value13 = value9 % 60;
  const value14 = [];
  if (value10) {
    value14.push(value10 + "d");
  }
  if (value11) {
    value14.push(value11 + "h");
  }
  if (value12) {
    value14.push(value12 + "m");
  }
  value14.push(value13 + "s");
  return value14.join(" ");
}
function formatMemory(value15) {
  if (value15 >= 1073741824) {
    return (value15 / 1073741824).toFixed(2) + " GB";
  }
  if (value15 >= 1048576) {
    return (value15 / 1048576).toFixed(1) + " MB";
  }
  return (value15 / 1024).toFixed(0) + " KB";
}
const progressBar = (value16, value17, value18 = 10) => {
  return "[⌛] " + Math.round(value16 / value17 * 100) + "%";
};
const CATEGORY_ORDER = ["owner", "general", "ai", "admin", "media", "aivideo", "games", "fun", "reaction", "anime", "sports", "movies", "convert", "design", "tools", "utility", "notes", "stalker", "religeon", "textmaker"];
const CATEGORY_LABELS = {
  owner: "OWNER",
  general: "GENERAL",
  ai: "AI",
  admin: "ADMIN",
  media: "MEDIA",
  aivideo: "VIDEO",
  games: "GAMES",
  utility: "TOOLS",
  fun: "FUN",
  reaction: "REACTIONS",
  anime: "ANIME",
  sports: "SPORTS",
  movies: "MOVIES",
  convert: "CONVERT",
  design: "DESIGN",
  tools: "TOOLS",
  notes: "NOTES",
  stalker: "LOOKUP",
  religeon: "RELIGION",
  textmaker: "TEXT"
};
function buildMenuText(value21, value22, value23, value24) {
  const value25 = db.getBotSetting("prefix");
  const value26 = db.getBotSetting("botName") || "TALKLESS XMD";
  const value27 = "TALKLESS";
  const value28 = detectPlatform();
  const value29 = formatUptime();
  const {
    getModeLabel: value30
  } = require("../../utils/botMode");
  const value31 = value30();
  const value32 = os.totalmem();
  const value33 = process.memoryUsage().rss;
  const value34 = value32 - os.freemem();
  const value35 = String.fromCharCode(8206).repeat(4001);
  const value36 = Number.isInteger(value24) ? "" + value24 : value24.toFixed(2);
  let value37 = {
    showUptime: true,
    showMemory: true,
    showProgressBar: true,
    showPluginCount: true
  };
  try {
    const value38 = require("../../database");
    if (value38.getMenuSettings) {
      value37 = {
        ...value37,
        ...value38.getMenuSettings()
      };
    }
  } catch {}
  let value39 = "╔═✦ `" + value26 + "` ✦\n";
  value39 += "║ • *ᴘʀᴇꜰɪx:* `[ " + value25 + " ]`\n";
  value39 += "║ • *ᴏᴡɴᴇʀ:* `" + value27 + "`\n";
  value39 += "║ • *ᴍᴏᴅᴇ:* `" + value31 + "`\n";
  value39 += "║ • *ᴘʟᴀᴛꜰᴏʀᴍ:* `" + value28 + "`\n";
  value39 += "║ • *ꜱᴘᴇᴇᴅ:* `" + value36 + " ms`\n";
  if (value37.showUptime) {
    value39 += "║ • *ᴜᴘᴛɪᴍᴇ:* `" + value29 + "`\n";
  }
  value39 += "║ • *Vᴇʀꜱɪᴏɴ:* `v" + db.VERSION + "`\n";
  if (value37.showMemory) {
    value39 += "║ • *ᴜꜱᴀɢᴇ:* `" + formatMemory(value33) + "`\n";
    value39 += "║ • *ᴛᴏᴛᴀʟ:* `" + formatMemory(value32) + "`\n";
  }
  if (value37.showProgressBar) {
    value39 += "║ • *ʀᴀᴍ:* `" + progressBar(value34, value32) + "`\n";
  }
  if (value37.showPluginCount) {
    value39 += "║ • *CMDS:* `" + value23 + "`\n";
  }
  value39 += "╚═✦\n" + value35 + "\n";
  const value40 = Object.keys(value21).filter(value41 => value21[value41]?.length > 0);
  const value42 = [...CATEGORY_ORDER.filter(value43 => value40.includes(value43)), ...value40.filter(value44 => !CATEGORY_ORDER.includes(value44)).sort()];
  let value45 = 0;
  for (const value46 of value42) {
    const value47 = value21[value46];
    if (!value47 || value47.length === 0) {
      continue;
    }
    const value48 = CATEGORY_LABELS[value46] || value46.toUpperCase() + "-CMD";
    value39 += "╔═✧ *~" + value48 + "~* ✧\n";
    for (const value49 of value47) {
      value39 += "║ ✰ " + value49.name + "\n";
    }
    value39 += "╚═✧\n";
    value45++;
    if (value45 % 3 === 0) {
      value39 += value35 + "\n";
    } else {
      value39 += "\n";
    }
  }
  return value39;
}
function getThumbnail() {
  try {
    const value50 = require("../../database");
    const value51 = value50.getMenuImageSettings ? value50.getMenuImageSettings() : null;
    if (value51 && value51.custom && value51.imageData) {
      let value52 = String(value51.imageData).trim();
      if (value52.startsWith("data:")) {
        value52 = value52.slice(value52.indexOf(",") + 1);
      }
      const value53 = Buffer.from(value52, "base64");
      if (value53 && value53.length) {
        return value53;
      }
    }
  } catch (error54) {}
  const value55 = path.join(__dirname, "../../data/custom_menu.jpg");
  if (fs.existsSync(value55)) {
    try {
      return fs.readFileSync(value55);
    } catch {}
  }
  const value56 = [path.join(__dirname, "../../utils/bot_image.jpg"), path.join(__dirname, "../../utils/menu2.jpg"), path.join(__dirname, "../../utils/menu3.jpg")];
  const value57 = value56.filter(value58 => {
    try {
      return fs.existsSync(value58);
    } catch {
      return false;
    }
  });
  if (!value57.length) {
    return null;
  }
  const value59 = value57[menuImageIndex++ % value57.length];
  try {
    return fs.readFileSync(value59);
  } catch {
    return null;
  }
}
module.exports = {
  name: "menu",
  aliases: ["menulist", "fullmenu"],
  category: "general",
  description: "Show all available commands",
  usage: ".menu",
  async execute(value60, value61, value62, value63) {
    try {
      const value64 = loadCommands();
      const value65 = {};
      let value66 = 0;
      value64.forEach((value67, value68) => {
        if (value67.name === value68) {
          if (!value65[value67.category]) {
            value65[value67.category] = [];
          }
          value65[value67.category].push(value67);
          value66++;
        }
      });
      const value73 = value61.messageTimestamp ? value61.messageTimestamp * 1000 : Date.now();
      const value74 = Date.now() - value73;
      const value75 = buildMenuText(value65, value63, value66, value74);
      const value76 = getThumbnail();
      const value77 = db.getBotSetting("botName") || "TALKLESS XMD";
      const value78 = (Array.isArray(db.getOwnerNames()) ? db.getOwnerNames()[0] : db.getOwnerNames()) || "Bot Owner";
      const value80 = value63.from;
      const value81 = applyFont(value75 + ("\n> " + db.getBotSetting("botName")));
      const value83 = db.getBotSetting("prefix") || ".";
      await sendButtons(value60, value80, {
        image: value76 ? {
          buffer: value76,
          mimetype: "image/jpeg"
        } : undefined,
        text: value81,
        mentions: [value63.sender],
        contextInfo: {
          externalAdReply: {
            showAdAttribution: false,
            title: value77,
            body: value78,
            thumbnail: value76,
            sourceUrl: "https://talkless.co.ke",
            mediaType: 1,
            renderLargerThumbnail: true
          }
        },
        buttons: [{
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🌐 𝚅𝙸𝚂𝙸𝚃 𝚆𝙴𝙱𝚂𝙸𝚃𝙴",
            url: "https://talkless.co.ke"
          })
        }, {
          id: value83 + "ping",
          text: "⏳ 𝙲𝙷𝙴𝙲𝙺 𝙿𝙸𝙽𝙶"
        }]
      });
    } catch (error87) {
      console.error("Menu error:", error87);
      await value63.reply("❌ Error: " + error87.message);
    }
  }
};
