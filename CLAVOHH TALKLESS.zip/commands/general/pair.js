const axios = require("axios");
const {
  sendButtons
} = require("gifted-btns");
const sleep = value1 => new Promise(value2 => setTimeout(value2, value1));
module.exports = {
  name: "pair",
  aliases: ["paircode", "linkdevice"],
  category: "general",
  description: "Generate a pairing code to link a WhatsApp number",
  usage: ".pair <number>  e.g. .pair 254799984735",
  async execute(value3, value4, value5, value6) {
    const value7 = value6.from;
    try {
      const value8 = value5.join(" ").trim();
      if (!value8) {
        await value3.sendMessage(value7, {
          text: "❌ *PAIRING NUMBER REQUIRED*\n\nSend the WhatsApp number with country code.\nExample: `.pair 254799984735`"
        }, {
          quoted: value4
        });
        await value3.sendMessage(value7, {
          react: {
            text: "🚫",
            key: value4.key
          }
        });
        return;
      }
      const value9 = value8.split(",").map(value10 => value10.replace(/[^0-9]/g, "")).filter(value11 => value11.length >= 6 && value11.length <= 20);
      if (value9.length === 0) {
        await value3.sendMessage(value7, {
          text: "❌ *INVALID NUMBER*\n\nUse digits only, including the country code.\nLength: 6–20 digits.\nExample: `.pair 254799984735`"
        }, {
          quoted: value4
        });
        await value3.sendMessage(value7, {
          react: {
            text: "🚫",
            key: value4.key
          }
        });
        return;
      }
      for (const value12 of value9) {
        const value13 = value12 + "@s.whatsapp.net";
        const value14 = await value3.onWhatsApp(value13);
        if (!value14?.[0]?.exists) {
          await value3.sendMessage(value7, {
            text: "❌ *NUMBER NOT FOUND*\n\n`" + value12 + "` is not registered on WhatsApp.\nCheck the number and try again."
          });
          await value3.sendMessage(value7, {
            react: {
              text: "🚫",
              key: value4.key
            }
          });
          continue;
        }
        await value3.sendMessage(value7, {
          text: "⏳ *PAIRING IN PROGRESS*\n\nNumber: `" + value12 + "`\nStatus: Generating a secure code..."
        }, {
          quoted: value4
        });
        await value3.sendMessage(value7, {
          react: {
            text: "⌛",
            key: value4.key
          }
        });
        try {
          const value15 = await axios.get("https://pair-TALKLESS XMD.onrender.com/code?number=" + value12, {
            timeout: 20000
          });
          const value16 = value15.data?.code;
          if (!value16 || value16 === "Service Unavailable") {
            throw new Error("Service Unavailable");
          }
          await sleep(3000);
          await sendButtons(value3, value7, {
            text: "✅ *PAIRING CODE READY*\n\nNumber: `" + value12 + "`\nCode:\n```" + value16 + "```\n\n*Link this device*\n1. Open WhatsApp.\n2. Open *Linked Devices*.\n3. Select *Link a Device*.\n4. Choose *Link with phone number instead*.\n5. Enter the code above.\n\n_The code expires soon._",
            buttons: [{
              name: "cta_copy",
              buttonParamsJson: JSON.stringify({
                display_text: "📋 Copy Code",
                copy_code: value16
              })
            }]
          }, {
            quoted: value4
          });
          await value3.sendMessage(value7, {
            react: {
              text: "✅",
              key: value4.key
            }
          });
        } catch (error17) {
          console.error("Pair API Error:", error17.message);
          const value18 = error17.message === "Service Unavailable" ? "⚠️ *PAIRING SERVICE UNAVAILABLE*\n\nPlease try again later." : "❌ *PAIRING FAILED*\n\nA pairing code could not be generated. Please try again.";
          await value3.sendMessage(value7, {
            text: value18
          }, {
            quoted: value4
          });
          await value3.sendMessage(value7, {
            react: {
              text: "🚫",
              key: value4.key
            }
          });
        }
      }
    } catch (error19) {
      console.error("Pair command error:", error19);
      await value3.sendMessage(value7, {
        text: "❌ *PAIRING ERROR*\n\nAn unexpected error occurred. Please try again later."
      }, {
        quoted: value4
      });
      await value3.sendMessage(value7, {
        react: {
          text: "⌛",
          key: value4.key
        }
      });
    }
  }
};
