const os = require("os");
function detectPlatform() {
  return "Heroku";
}
function formatUptime(value1) {
  if (value1 <= 0) {
    return "0 seconds";
  }
  const value2 = Math.floor(value1 / 86400);
  const value3 = Math.floor(value1 % 86400 / 3600);
  const value4 = Math.floor(value1 % 3600 / 60);
  const value5 = Math.floor(value1 % 60);
  const value6 = [];
  if (value2 > 0) {
    value6.push(value2 + " " + (value2 === 1 ? "day" : "days"));
  }
  if (value3 > 0) {
    value6.push(value3 + " " + (value3 === 1 ? "hour" : "hours"));
  }
  if (value4 > 0) {
    value6.push(value4 + " " + (value4 === 1 ? "minute" : "minutes"));
  }
  if (value5 > 0 || value6.length === 0) {
    value6.push(value5 + " " + (value5 === 1 ? "second" : "seconds"));
  }
  return value6.join(", ");
}
module.exports = {
  name: "uptime",
  aliases: ["runtime", "botuptime", "up"],
  category: "general",
  description: "Show how long the bot has been running",
  usage: ".uptime",
  async execute(value7, value8, value9, value10) {
    try {
      const value11 = process.uptime();
      const value12 = formatUptime(value11);
      const value13 = detectPlatform();
      const value14 = process.memoryUsage();
      const value15 = (value14.heapUsed / 1024 / 1024).toFixed(1);
      const value16 = (value14.heapTotal / 1024 / 1024).toFixed(1);
      const value17 = "⌚ Uptime: " + value12.replace(/ hours?/g, "h").replace(/ minutes?/g, "m").replace(/ seconds?/g, "s").replace(/ days?/g, "d") + "\n" + "🖥️ Platform: " + value13 + "\n" + "📋 Memory:  `" + value15 + " MB / " + value16 + " MB`\n\n> BY TALKLESS";
      await value10.reply(value17);
    } catch (error18) {
      console.error("Error in uptime command:", error18);
      await value10.reply("❌ An error occurred while fetching uptime information. Please try again later.");
    }
  }
};
