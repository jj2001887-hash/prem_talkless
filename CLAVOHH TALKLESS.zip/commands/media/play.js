const songCommand = require("./song");

module.exports = {
  ...songCommand,
  name: "play2",
  aliases: ["song2", "yta2"],
  usage: ".play2 <song name or YouTube URL>",
  description: "Search YouTube and send a playable MP3 audio file"
};
