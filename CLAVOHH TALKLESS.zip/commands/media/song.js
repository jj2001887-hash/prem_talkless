"use strict";

const yts = require("yt-search");
const axios = require("axios");
const { downloadYoutube, downloadRemoteAudio } = require("../../utils/youtubeMedia");
const APIs = require("../../utils/api");
const { withTimeout, createTtlCache, dedupe, firstSuccess, youtubeId } = require("../../utils/fastMedia");

const searchCache = createTtlCache({ ttlMs: 30 * 60 * 1000, maxEntries: 200 });
const audioCache = createTtlCache({ ttlMs: 20 * 60 * 1000, maxEntries: 8, maxBytes: 80 * 1024 * 1024 });

const XCASPER_MUSIC = "https://ytm.xcasper.space";

function isUrl(value) {
  return /^https?:\/\//i.test(String(value || ""));
}

function summary(video) {
  return `🎵 *TALKLESS MUSIC PLAYER*\n\n` +
    `✰ *Title:* ${video.title}\n` +
    `✰ *Artist:* ${video.author?.name || "Unknown"}\n` +
    `✰ *Duration:* ${video.timestamp || "Unknown"}\n\n` +
    `⏳ Preparing your audio...`;
}

async function casperMusicSearch(query) {
  const response = await axios.get(`${XCASPER_MUSIC}/api/search`, {
    params: { q: query },
    timeout: 6000,
    headers: { Accept: "application/json", "User-Agent": "TALKLESS-XMD/4.0" }
  });
  const data = response.data || {};
  const results = data.result?.results || data.results || [];
  const item = results.find(value => value?.videoId) || data.result?.topResult || data.topResult;
  if (!item?.videoId) throw new Error("Music search returned no playable result");
  return {
    id: item.videoId,
    title: item.title || "YouTube Music",
    author: { name: item.artists?.map(value => value.name).filter(Boolean).join(", ") || item.artist || item.subtitle || "Unknown" },
    timestamp: item.duration || "Unknown",
    url: `https://www.youtube.com/watch?v=${item.videoId}`
  };
}

async function casperMusicDownload(video) {
  if (!video.id) throw new Error("Music result has no video ID");
  return downloadRemoteAudio(`${XCASPER_MUSIC}/api/download/${video.id}?format=mp3`, video.title);
}

async function providerAudio(video) {
  const providers = [
    APIs.getVredenYouTubeAudio,
    APIs.getNekoYouTubeAudio,
    APIs.getIzumiDownloadByUrl,
    APIs.getCobaltYouTubeAudio
  ].filter(fn => typeof fn === "function");
  if (!providers.length) throw new Error("No audio providers available");
  // All providers are asked at the same time; the first one that delivers audio wins.
  return firstSuccess(providers.map(provider => async () => {
    const result = await withTimeout(provider(video.url), 12000, "audio provider");
    const remoteUrl = result?.download || result?.url;
    if (!remoteUrl) throw new Error("Provider returned no download URL");
    return withTimeout(downloadRemoteAudio(remoteUrl, result.title || video.title, 30000), 35000, "audio download");
  }));
}

async function resolveAudio(video) {
  const key = video.id || video.url;
  const cached = key && audioCache.get(key);
  if (cached) return cached;
  const run = async () => {
    let media;
    try {
      // Fast path: the primary host and the backup providers race each other.
      media = await firstSuccess([
        () => withTimeout(casperMusicDownload(video), 30000, "primary audio"),
        () => providerAudio(video)
      ]);
    } catch {
      // Slow but reliable last resort.
      media = await downloadYoutube(video.url, "audio", video.title);
    }
    if (key) audioCache.set(key, media);
    return media;
  };
  return key ? dedupe("audio:" + key, run) : run();
}

async function findVideo(query) {
  const cacheKey = query.toLowerCase();
  const cached = searchCache.get(cacheKey);
  if (cached) return { ...cached };
  const found = await firstSuccess([
    () => casperMusicSearch(query),
    async () => {
      const results = await withTimeout(yts(query), 8000, "yt-search");
      const top = results.videos?.[0];
      if (!top) throw new Error("No matching song was found");
      top.id = top.videoId || top.id;
      return top;
    }
  ]);
  searchCache.set(cacheKey, found);
  return { ...found };
}

module.exports = {
  name: "play",
  aliases: ["song", "yta"],
  category: "media",
  description: "Search YouTube Music and send a playable MP3 audio file.",
  usage: ".play <song name or YouTube URL>",
  async execute(sock, message, args, context) {
    const destination = context.from || message.key.remoteJid;
    const query = args.join(" ").trim();
    if (!query) return context.reply("🎵 *TALKLESS MUSIC PLAYER*\n\nPlease enter a song name or YouTube URL.\n\nExample: .play Calm Down\n\n> BY TALKLESS");
    try {
      await sock.sendMessage(destination, { react: { text: "⌛", key: message.key } });
      let video;
      if (isUrl(query)) {
        const id = youtubeId(query);
        video = id ? await withTimeout(yts({ videoId: id }), 8000, "yt-search").catch(() => ({ title: query })) : { title: query };
        video.url = query;
        video.id = id;
      } else {
        video = await findVideo(query);
      }
      // Send the song card right away so the user sees an instant response while audio prepares.
      context.reply(summary(video)).catch(() => {});
      const media = await resolveAudio(video);
      await sock.sendMessage(destination, {
        audio: media.buffer,
        mimetype: "audio/mpeg",
        fileName: media.fileName,
        ptt: false
      }, { quoted: message });
      await sock.sendMessage(destination, { react: { text: "✅", key: message.key } });
    } catch (error) {
      console.error("[PLAY] music download:", error.message);
      await sock.sendMessage(destination, { react: { text: "❌", key: message.key } });
      await context.reply("❌ *Music download failed*\n\nTALKLESS could not return a playable audio file right now. Try another title or URL.\n\n> BY TALKLESS");
    }
  }
};
