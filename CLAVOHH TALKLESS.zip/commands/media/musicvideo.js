"use strict";

const videoCommand = require("./video");

module.exports = {
  ...videoCommand,
  name: "musicvideo",
  aliases: ["mv", "mvideo", "ytmusicvideo"],
  description: "Search and download a public YouTube music video.",
  usage: ".musicvideo <song title or YouTube URL>"
};
