"use strict";

const yts = require("yt-search");
const axios = require("axios");
const { downloadYoutube, downloadRemoteVideo } = require("../../utils/youtubeMedia");
const { withTimeout, createTtlCache, dedupe, firstSuccess, youtubeId } = require("../../utils/fastMedia");

const searchCache = createTtlCache({ ttlMs: 30 * 60 * 1000, maxEntries: 200 });
const videoCache = createTtlCache({ ttlMs: 15 * 60 * 1000, maxEntries: 4, maxBytes: 100 * 1024 * 1024 });

const XCASPER_VIDEO = "https://ytv.xcasper.space";

function isUrl(value) {
  return /^https?:\/\//i.test(String(value || ""));
}

async function casperVideoSearch(query) {
  const response = await axios.get(`${XCASPER_VIDEO}/api/search`, {
    params: { q: query, type: "video" },
    timeout: 6000,
    headers: { Accept: "application/json", "User-Agent": "TALKLESS-XMD/4.0" }
  });
  const item = response.data?.results?.find(value => value?.id);
  if (!item?.id) throw new Error("Video search returned no playable result");
  return {
    id: item.id,
    title: item.title || "YouTube video",
    channel: item.channel || "Unknown",
    url: `https://www.youtube.com/watch?v=${item.id}`
  };
}

async function casperVideoDownload(video) {
  if (!video.id) throw new Error("Video result has no video ID");
  return downloadRemoteVideo(`${XCASPER_VIDEO}/api/download/${video.id}?format=mp4&quality=360`, video.title);
}

module.exports = {
  name: "ytvideo",
  aliases: ["ytv", "ytmp4", "ytvid", "video"],
  category: "media",
  description: "Download a public YouTube video through the TALKLESS media fallbacks.",
  usage: ".video <video name or YouTube URL>",
  async execute(sock, message, args, context) {
    const destination = context.from || message.key.remoteJid;
    const query = args.join(" ").trim();
    if (!query) return context.reply("🎬 *VIDEO DOWNLOADER*\n\nProvide a public YouTube URL or video title.\n\n> BY TALKLESS");
    try {
      await sock.sendMessage(destination, { react: { text: "⌛", key: message.key } });
      let video;
      if (isUrl(query)) {
        const id = youtubeId(query);
        video = id ? await withTimeout(yts({ videoId: id }), 8000, "yt-search").catch(() => ({ title: "YouTube video" })) : { title: "YouTube video" };
        video.url = query;
        video.id = id;
      } else {
        const cacheKey = query.toLowerCase();
        video = searchCache.get(cacheKey);
        if (!video) {
          video = await firstSuccess([
            () => casperVideoSearch(query),
            async () => {
              const results = await withTimeout(yts(query), 8000, "yt-search");
              const top = results.videos?.[0];
              if (!top) throw new Error("No matching video was found");
              top.id = top.videoId || top.id;
              return top;
            }
          ]);
          searchCache.set(cacheKey, video);
        }
        video = { ...video };
      }
      const key = video.id || video.url;
      let media = key && videoCache.get(key);
      if (!media) {
        const run = async () => {
          let result;
          try {
            result = await withTimeout(casperVideoDownload(video), 45000, "video download");
          } catch {
            result = await downloadYoutube(video.url, "video", video.title);
          }
          if (key) videoCache.set(key, result);
          return result;
        };
        media = key ? await dedupe("video:" + key, run) : await run();
      }
      await sock.sendMessage(destination, {
        video: media.buffer,
        mimetype: "video/mp4",
        fileName: media.fileName,
        caption: `🎬 *${video.title}*\n\n> BY TALKLESS`
      }, { quoted: message });
      await sock.sendMessage(destination, { react: { text: "✅", key: message.key } });
    } catch (error) {
      console.error("[VIDEO] download:", error.message);
      await sock.sendMessage(destination, { react: { text: "❌", key: message.key } });
      await context.reply("❌ *Video download failed*\n\nTALKLESS could not return a sendable MP4 right now. Try another public URL or title.\n\n> BY TALKLESS");
    }
  }
};
