const REACTION_MESSAGES = {
  kiss: "💋 Sending you a warm kiss.",
  cry: "😢 It is okay to feel this way. I am here with you.",
  blush: "☺️ That is making me blush.",
  dance: "💃 Let us celebrate and dance it out.",
  kill: "😤 That energy is intense. Take a breath first.",
  hug: "🫂 Sending you a big, comforting hug.",
  kick: "🦶 A playful kick sent your way.",
  slap: "🙃 Easy there. Let us keep it calm.",
  happy: "😊 I am happy to see you feeling good.",
  bully: "🛑 Be kind. Nobody deserves bullying.",
  pat: "🤍 You are doing well. Keep going.",
  wink: "😉 I know exactly what you mean.",
  poke: "👉 Poke. I am paying attention now.",
  cuddle: "🤗 Come here, you deserve a cuddle.",
  highfive: "🙌 High five. We are in this together.",
  smile: "😄 Keep that smile going.",
  wave: "👋 Hello there. Good to see you.",
  bite: "😅 A playful bite, nothing serious.",
  lick: "😅 Let us keep that playful energy friendly.",
  bonk: "🔨 Bonk. Consider that a gentle reminder.",
  yeet: "🚀 And away it goes.",
  glomp: "🫂 Surprise hug incoming.",
  stab: "🛑 No violence. Let us choose peace instead.",
  nom: "🍴 Time for a little snack.",
  tickle: "😂 That tickle got you laughing.",
  throw: "💨 And that went flying.",
  facepalm: "🤦 I understand the frustration.",
  feed: "🍽️ Here, have something to eat.",
  spank: "🙃 Keep it respectful and playful.",
  handhold: "🤝 You do not have to face it alone.",
  shoot: "🎯 Aim for your goals, not people.",
  punch: "🥊 Let us put that energy into something positive.",
  stare: "👀 I see you.",
  comfort: "🫂 You are not alone. Things can get better.",
  boop: "👉 Boop. That should brighten your day.",
  sleep: "😴 Rest well. Tomorrow is another chance.",
  shrug: "🤷 Sometimes, that is just how it goes.",
  sip: "☕ Take a sip and slow down for a moment.",
  clap: "👏 Well done. You deserve the applause.",
  nervous: "😰 Take a slow breath. You can handle this.",
  scream: "😱 Let it out, then take a deep breath.",
  pout: "🥺 Do not stay upset. I am listening.",
  bored: "😐 Let us find something fun to do.",
  laugh: "😂 That was genuinely funny.",
  shy: "🙈 No need to hide. You are safe here.",
  confused: "🤔 Let us slow down and figure it out.",
  angry: "😠 I understand you are angry. Take a moment before reacting.",
  excited: "🤩 That excitement is contagious.",
  fear: "😟 You are safe. Face it one step at a time.",
  surprised: "😲 That was unexpected.",
  thinking: "🤔 Give it a moment. The answer will come.",
  embarrassed: "😳 It happens to everyone. Do not be too hard on yourself.",
  tired: "😮‍💨 You have done enough for now. Get some rest.",
  sad: "💙 I am sorry you are feeling sad. You do not have to face it alone.",
  love: "❤️ Sending you love and good energy.",
  peace: "☮️ Choose peace and protect your calm.",
  victory: "🏆 Congratulations. That is a win.",
  point: "👉 Point taken. I am listening."
};
const fetchReactionMessage = async ({
  extra: value1,
  command: value2
}) => {
  const value3 = REACTION_MESSAGES[value2] || "💬 I understand the feeling behind that reaction.";
  await value1.reply(value3 + "\n\n> BY TALKLESS");
};
module.exports = [{
  command: ["kiss", "cium", "beso"],
  name: "kiss",
  category: "reaction",
  description: "Send a kiss reaction message",
  usage: ".kiss",
  execute: async (value16, value17, value18, value19) => {
    await fetchReactionMessage({
      sock: value16,
      msg: value17,
      extra: value19,
      command: "kiss"
    });
  }
}, {
  command: ["cry"],
  name: "cry",
  category: "reaction",
  description: "Send a cry reaction message",
  usage: ".cry",
  execute: async (value20, value21, value22, value23) => {
    await fetchReactionMessage({
      sock: value20,
      msg: value21,
      extra: value23,
      command: "cry"
    });
  }
}, {
  command: ["blush"],
  name: "blush",
  category: "reaction",
  description: "Send a blush reaction message",
  usage: ".blush",
  execute: async (value24, value25, value26, value27) => {
    await fetchReactionMessage({
      sock: value24,
      msg: value25,
      extra: value27,
      command: "blush"
    });
  }
}, {
  command: ["dance"],
  name: "dance",
  category: "reaction",
  description: "Send a dance reaction message",
  usage: ".dance",
  execute: async (value28, value29, value30, value31) => {
    await fetchReactionMessage({
      sock: value28,
      msg: value29,
      extra: value31,
      command: "dance"
    });
  }
}, {
  command: ["killgif"],
  name: "killgif",
  category: "reaction",
  description: "Send a kill reaction message",
  usage: ".killgif",
  execute: async (value32, value33, value34, value35) => {
    await fetchReactionMessage({
      sock: value32,
      msg: value33,
      extra: value35,
      command: "kill"
    });
  }
}, {
  command: ["hug"],
  name: "hug",
  category: "reaction",
  description: "Send a hug reaction message",
  usage: ".hug",
  execute: async (value36, value37, value38, value39) => {
    await fetchReactionMessage({
      sock: value36,
      msg: value37,
      extra: value39,
      command: "hug"
    });
  }
}, {
  command: ["kickgif", "kick3"],
  name: "kickgif",
  category: "reaction",
  description: "Send a kick reaction message",
  usage: ".kickgif",
  execute: async (value40, value41, value42, value43) => {
    await fetchReactionMessage({
      sock: value40,
      msg: value41,
      extra: value43,
      command: "kick"
    });
  }
}, {
  command: ["slap"],
  name: "slap",
  category: "reaction",
  description: "Send a slap reaction message",
  usage: ".slap",
  execute: async (value44, value45, value46, value47) => {
    await fetchReactionMessage({
      sock: value44,
      msg: value45,
      extra: value47,
      command: "slap"
    });
  }
}, {
  command: ["happy"],
  name: "happy",
  category: "reaction",
  description: "Send a happy reaction message",
  usage: ".happy",
  execute: async (value48, value49, value50, value51) => {
    await fetchReactionMessage({
      sock: value48,
      msg: value49,
      extra: value51,
      command: "happy"
    });
  }
}, {
  command: ["bully"],
  name: "bully",
  category: "reaction",
  description: "Send a bully reaction message",
  usage: ".bully",
  execute: async (value52, value53, value54, value55) => {
    await fetchReactionMessage({
      sock: value52,
      msg: value53,
      extra: value55,
      command: "bully"
    });
  }
}, {
  command: ["pat", "headpat"],
  name: "pat",
  category: "reaction",
  description: "Send a head pat reaction message",
  usage: ".pat",
  execute: async (value56, value57, value58, value59) => {
    await fetchReactionMessage({
      sock: value56,
      msg: value57,
      extra: value59,
      command: "pat"
    });
  }
}, {
  command: ["wink"],
  name: "wink",
  category: "reaction",
  description: "Send a wink reaction message",
  usage: ".wink",
  execute: async (value60, value61, value62, value63) => {
    await fetchReactionMessage({
      sock: value60,
      msg: value61,
      extra: value63,
      command: "wink"
    });
  }
}, {
  command: ["poke"],
  name: "poke",
  category: "reaction",
  description: "Send a poke reaction message",
  usage: ".poke",
  execute: async (value64, value65, value66, value67) => {
    await fetchReactionMessage({
      sock: value64,
      msg: value65,
      extra: value67,
      command: "poke"
    });
  }
}, {
  command: ["cuddle"],
  name: "cuddle",
  category: "reaction",
  description: "Send a cuddle reaction message",
  usage: ".cuddle",
  execute: async (value68, value69, value70, value71) => {
    await fetchReactionMessage({
      sock: value68,
      msg: value69,
      extra: value71,
      command: "cuddle"
    });
  }
}, {
  command: ["highfive", "hi5"],
  name: "highfive",
  category: "reaction",
  description: "Send a high five reaction message",
  usage: ".highfive",
  execute: async (value72, value73, value74, value75) => {
    await fetchReactionMessage({
      sock: value72,
      msg: value73,
      extra: value75,
      command: "highfive"
    });
  }
}, {
  command: ["smile"],
  name: "smile",
  category: "reaction",
  description: "Send a smile reaction message",
  usage: ".smile",
  execute: async (value76, value77, value78, value79) => {
    await fetchReactionMessage({
      sock: value76,
      msg: value77,
      extra: value79,
      command: "smile"
    });
  }
}, {
  command: ["wave"],
  name: "wave",
  category: "reaction",
  description: "Send a wave reaction message",
  usage: ".wave",
  execute: async (value80, value81, value82, value83) => {
    await fetchReactionMessage({
      sock: value80,
      msg: value81,
      extra: value83,
      command: "wave"
    });
  }
}, {
  command: ["bite"],
  name: "bite",
  category: "reaction",
  description: "Send a bite reaction message",
  usage: ".bite",
  execute: async (value84, value85, value86, value87) => {
    await fetchReactionMessage({
      sock: value84,
      msg: value85,
      extra: value87,
      command: "bite"
    });
  }
}, {
  command: ["lick"],
  name: "lick",
  category: "reaction",
  description: "Send a lick reaction message",
  usage: ".lick",
  execute: async (value88, value89, value90, value91) => {
    await fetchReactionMessage({
      sock: value88,
      msg: value89,
      extra: value91,
      command: "lick"
    });
  }
}, {
  command: ["bonk"],
  name: "bonk",
  category: "reaction",
  description: "Send a bonk reaction message",
  usage: ".bonk",
  execute: async (value92, value93, value94, value95) => {
    await fetchReactionMessage({
      sock: value92,
      msg: value93,
      extra: value95,
      command: "bonk"
    });
  }
}, {
  command: ["yeet"],
  name: "yeet",
  category: "reaction",
  description: "Send a yeet reaction message",
  usage: ".yeet",
  execute: async (value96, value97, value98, value99) => {
    await fetchReactionMessage({
      sock: value96,
      msg: value97,
      extra: value99,
      command: "yeet"
    });
  }
}, {
  command: ["glomp"],
  name: "glomp",
  category: "reaction",
  description: "Send a glomp reaction message",
  usage: ".glomp",
  execute: async (value100, value101, value102, value103) => {
    await fetchReactionMessage({
      sock: value100,
      msg: value101,
      extra: value103,
      command: "glomp"
    });
  }
}, {
  command: ["stab"],
  name: "stab",
  category: "reaction",
  description: "Send a stab reaction message",
  usage: ".stab",
  execute: async (value104, value105, value106, value107) => {
    await fetchReactionMessage({
      sock: value104,
      msg: value105,
      extra: value107,
      command: "stab"
    });
  }
}, {
  command: ["nom"],
  name: "nom",
  category: "reaction",
  description: "Send a nom reaction message",
  usage: ".nom",
  execute: async (value108, value109, value110, value111) => {
    await fetchReactionMessage({
      sock: value108,
      msg: value109,
      extra: value111,
      command: "nom"
    });
  }
}, {
  command: ["tickle"],
  name: "tickle",
  category: "reaction",
  description: "Send a tickle reaction message",
  usage: ".tickle",
  execute: async (value112, value113, value114, value115) => {
    await fetchReactionMessage({
      sock: value112,
      msg: value113,
      extra: value115,
      command: "tickle"
    });
  }
}, {
  command: ["throw"],
  name: "throw",
  category: "reaction",
  description: "Send a throw reaction message",
  usage: ".throw",
  execute: async (value116, value117, value118, value119) => {
    await fetchReactionMessage({
      sock: value116,
      msg: value117,
      extra: value119,
      command: "throw"
    });
  }
}, {
  command: ["facepalm"],
  name: "facepalm",
  category: "reaction",
  description: "Send a facepalm reaction message",
  usage: ".facepalm",
  execute: async (value120, value121, value122, value123) => {
    await fetchReactionMessage({
      sock: value120,
      msg: value121,
      extra: value123,
      command: "facepalm"
    });
  }
}, {
  command: ["feed"],
  name: "feed",
  category: "reaction",
  description: "Send a feed reaction message",
  usage: ".feed",
  execute: async (value124, value125, value126, value127) => {
    await fetchReactionMessage({
      sock: value124,
      msg: value125,
      extra: value127,
      command: "feed"
    });
  }
}, {
  command: ["spank"],
  name: "spank",
  category: "reaction",
  description: "Send a spank reaction message",
  usage: ".spank",
  execute: async (value128, value129, value130, value131) => {
    await fetchReactionMessage({
      sock: value128,
      msg: value129,
      extra: value131,
      command: "spank"
    });
  }
}, {
  command: ["handhold", "holdhands"],
  name: "handhold",
  category: "reaction",
  description: "Send a handhold reaction message",
  usage: ".handhold",
  execute: async (value132, value133, value134, value135) => {
    await fetchReactionMessage({
      sock: value132,
      msg: value133,
      extra: value135,
      command: "handhold"
    });
  }
}, {
  command: ["shoot"],
  name: "shoot",
  category: "reaction",
  description: "Send a shoot reaction message",
  usage: ".shoot",
  execute: async (value136, value137, value138, value139) => {
    await fetchReactionMessage({
      sock: value136,
      msg: value137,
      extra: value139,
      command: "shoot"
    });
  }
}, {
  command: ["punch"],
  name: "punch",
  category: "reaction",
  description: "Send a punch reaction message",
  usage: ".punch",
  execute: async (value140, value141, value142, value143) => {
    await fetchReactionMessage({
      sock: value140,
      msg: value141,
      extra: value143,
      command: "punch"
    });
  }
}, {
  command: ["stare"],
  name: "stare",
  category: "reaction",
  description: "Send a stare reaction message",
  usage: ".stare",
  execute: async (value144, value145, value146, value147) => {
    await fetchReactionMessage({
      sock: value144,
      msg: value145,
      extra: value147,
      command: "stare"
    });
  }
}, {
  command: ["comfort"],
  name: "comfort",
  category: "reaction",
  description: "Send a comfort reaction message",
  usage: ".comfort",
  execute: async (value148, value149, value150, value151) => {
    await fetchReactionMessage({
      sock: value148,
      msg: value149,
      extra: value151,
      command: "comfort"
    });
  }
}, {
  command: ["boop", "boopnose"],
  name: "boop",
  category: "reaction",
  description: "Send a boop reaction message",
  usage: ".boop",
  execute: async (value152, value153, value154, value155) => {
    await fetchReactionMessage({
      sock: value152,
      msg: value153,
      extra: value155,
      command: "boop"
    });
  }
}, {
  command: ["sleep"],
  name: "sleep",
  category: "reaction",
  description: "Send a sleep reaction message",
  usage: ".sleep",
  execute: async (value156, value157, value158, value159) => {
    await fetchReactionMessage({
      sock: value156,
      msg: value157,
      extra: value159,
      command: "sleep"
    });
  }
}, {
  command: ["shrug"],
  name: "shrug",
  category: "reaction",
  description: "Send a shrug reaction message",
  usage: ".shrug",
  execute: async (value160, value161, value162, value163) => {
    await fetchReactionMessage({
      sock: value160,
      msg: value161,
      extra: value163,
      command: "shrug"
    });
  }
}, {
  command: ["sip"],
  name: "sip",
  category: "reaction",
  description: "Send a sip reaction message",
  usage: ".sip",
  execute: async (value164, value165, value166, value167) => {
    await fetchReactionMessage({
      sock: value164,
      msg: value165,
      extra: value167,
      command: "sip"
    });
  }
}, {
  command: ["clap"],
  name: "clap",
  category: "reaction",
  description: "Send a clap reaction message",
  usage: ".clap",
  execute: async (value168, value169, value170, value171) => {
    await fetchReactionMessage({
      sock: value168,
      msg: value169,
      extra: value171,
      command: "clap"
    });
  }
}, {
  command: ["nervous"],
  name: "nervous",
  category: "reaction",
  description: "Send a nervous reaction message",
  usage: ".nervous",
  execute: async (value172, value173, value174, value175) => {
    await fetchReactionMessage({
      sock: value172,
      msg: value173,
      extra: value175,
      command: "nervous"
    });
  }
}, {
  command: ["scream"],
  name: "scream",
  category: "reaction",
  description: "Send a scream reaction message",
  usage: ".scream",
  execute: async (value176, value177, value178, value179) => {
    await fetchReactionMessage({
      sock: value176,
      msg: value177,
      extra: value179,
      command: "scream"
    });
  }
}, {
  command: ["pout"],
  name: "pout",
  category: "reaction",
  description: "Send a pout reaction message",
  usage: ".pout",
  execute: async (value180, value181, value182, value183) => {
    await fetchReactionMessage({
      sock: value180,
      msg: value181,
      extra: value183,
      command: "pout"
    });
  }
}, {
  command: ["bored"],
  name: "bored",
  category: "reaction",
  description: "Send a bored reaction message",
  usage: ".bored",
  execute: async (value184, value185, value186, value187) => {
    await fetchReactionMessage({
      sock: value184,
      msg: value185,
      extra: value187,
      command: "bored"
    });
  }
}, {
  command: ["laugh"],
  name: "laugh",
  category: "reaction",
  description: "Send a laugh reaction message",
  usage: ".laugh",
  execute: async (value188, value189, value190, value191) => {
    await fetchReactionMessage({
      sock: value188,
      msg: value189,
      extra: value191,
      command: "laugh"
    });
  }
}, {
  command: ["shy"],
  name: "shy",
  category: "reaction",
  description: "Send a shy reaction message",
  usage: ".shy",
  execute: async (value192, value193, value194, value195) => {
    await fetchReactionMessage({
      sock: value192,
      msg: value193,
      extra: value195,
      command: "shy"
    });
  }
}, {
  command: ["confused"],
  name: "confused",
  category: "reaction",
  description: "Send a confused reaction message",
  usage: ".confused",
  execute: async (value196, value197, value198, value199) => {
    await fetchReactionMessage({
      sock: value196,
      msg: value197,
      extra: value199,
      command: "confused"
    });
  }
}, {
  command: ["angry"],
  name: "angry",
  category: "reaction",
  description: "Send an angry reaction message",
  usage: ".angry",
  execute: async (value200, value201, value202, value203) => {
    await fetchReactionMessage({
      sock: value200,
      msg: value201,
      extra: value203,
      command: "angry"
    });
  }
}, {
  command: ["excited"],
  name: "excited",
  category: "reaction",
  description: "Send an excited reaction message",
  usage: ".excited",
  execute: async (value204, value205, value206, value207) => {
    await fetchReactionMessage({
      sock: value204,
      msg: value205,
      extra: value207,
      command: "excited"
    });
  }
}, {
  command: ["fear"],
  name: "fear",
  category: "reaction",
  description: "Send a fear reaction message",
  usage: ".fear",
  execute: async (value208, value209, value210, value211) => {
    await fetchReactionMessage({
      sock: value208,
      msg: value209,
      extra: value211,
      command: "fear"
    });
  }
}, {
  command: ["surprised"],
  name: "surprised",
  category: "reaction",
  description: "Send a surprised reaction message",
  usage: ".surprised",
  execute: async (value212, value213, value214, value215) => {
    await fetchReactionMessage({
      sock: value212,
      msg: value213,
      extra: value215,
      command: "surprised"
    });
  }
}, {
  command: ["thinking"],
  name: "thinking",
  category: "reaction",
  description: "Send a thinking reaction message",
  usage: ".thinking",
  execute: async (value216, value217, value218, value219) => {
    await fetchReactionMessage({
      sock: value216,
      msg: value217,
      extra: value219,
      command: "thinking"
    });
  }
}, {
  command: ["embarrassed"],
  name: "embarrassed",
  category: "reaction",
  description: "Send an embarrassed reaction message",
  usage: ".embarrassed",
  execute: async (value220, value221, value222, value223) => {
    await fetchReactionMessage({
      sock: value220,
      msg: value221,
      extra: value223,
      command: "embarrassed"
    });
  }
}, {
  command: ["tired"],
  name: "tired",
  category: "reaction",
  description: "Send a tired reaction message",
  usage: ".tired",
  execute: async (value224, value225, value226, value227) => {
    await fetchReactionMessage({
      sock: value224,
      msg: value225,
      extra: value227,
      command: "tired"
    });
  }
}, {
  command: ["sad"],
  name: "sad",
  category: "reaction",
  description: "Send a sad reaction message",
  usage: ".sad",
  execute: async (value228, value229, value230, value231) => {
    await fetchReactionMessage({
      sock: value228,
      msg: value229,
      extra: value231,
      command: "sad"
    });
  }
}, {
  command: ["love"],
  name: "love",
  category: "reaction",
  description: "Send a love reaction message",
  usage: ".love",
  execute: async (value232, value233, value234, value235) => {
    await fetchReactionMessage({
      sock: value232,
      msg: value233,
      extra: value235,
      command: "love"
    });
  }
}, {
  command: ["peace"],
  name: "peace",
  category: "reaction",
  description: "Send a peace reaction message",
  usage: ".peace",
  execute: async (value236, value237, value238, value239) => {
    await fetchReactionMessage({
      sock: value236,
      msg: value237,
      extra: value239,
      command: "peace"
    });
  }
}, {
  command: ["victory", "victorysign"],
  name: "victory",
  category: "reaction",
  description: "Send a victory reaction message",
  usage: ".victory",
  execute: async (value240, value241, value242, value243) => {
    await fetchReactionMessage({
      sock: value240,
      msg: value241,
      extra: value243,
      command: "victory"
    });
  }
}, {
  command: ["point"],
  name: "point",
  category: "reaction",
  description: "Send a point reaction message",
  usage: ".point",
  execute: async (value244, value245, value246, value247) => {
    await fetchReactionMessage({
      sock: value244,
      msg: value245,
      extra: value247,
      command: "point"
    });
  }
}];
