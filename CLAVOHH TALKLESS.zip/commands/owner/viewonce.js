"use strict";

const { downloadContentFromMessage, jidNormalizedUser } = require("@whiskeysockets/baileys");
const voCache = require("../../utils/viewOnceCache");

const WRAPPERS = ["viewOnceMessageV2Extension", "viewOnceMessageV2", "viewOnceMessage"];
const MEDIA = { imageMessage: "image", videoMessage: "video", audioMessage: "audio" };

function unwrapEphemeral(message) {
  let current = message || {};
  for (let i = 0; i < 4; i++) {
    const inner = current.ephemeralMessage?.message || current.documentWithCaptionMessage?.message || current.editedMessage?.message;
    if (!inner) break;
    current = inner;
  }
  return current;
}

// Returns { media, type, dlType } for a view-once message, or null.
function extractViewOnce(message) {
  const base = unwrapEphemeral(message);
  for (const wrapper of WRAPPERS) {
    const inner = base[wrapper]?.message;
    if (inner) {
      const type = Object.keys(inner).find(key => MEDIA[key]);
      if (type) return { media: inner[type], type, dlType: MEDIA[type] };
    }
  }
  for (const type of Object.keys(MEDIA)) {
    if (base[type]?.viewOnce) return { media: base[type], type, dlType: MEDIA[type] };
  }
  return null;
}

async function toBuffer(media, dlType) {
  const stream = await downloadContentFromMessage(media, dlType);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  const buffer = Buffer.concat(chunks);
  if (!buffer.length) throw new Error("Downloaded media was empty");
  return buffer;
}

const digits = jid => String(jid || "").split("@")[0].split(":")[0].replace(/\D/g, "");

// Builds "👤 From: Name (+number)" for the person who sent the view-once.
function describeSender(sock, original, ctxInfo, chatJid) {
  const key = original?.key || {};
  const isGroup = String(chatJid).endsWith("@g.us");
  let jid = key.participantAlt || key.participant || ctxInfo?.participant || (isGroup ? "" : key.remoteJidAlt || key.remoteJid || chatJid);
  if (key.fromMe) jid = sock.user?.id || jid;
  const name = original?.pushName || "";
  const number = digits(jid);
  const isPhone = String(jid).includes("@s.whatsapp.net") || (number.length >= 7 && number.length <= 15 && !String(jid).includes("@lid"));
  const shown = isPhone && number ? "+" + number : "";
  if (name && shown) return name + " (" + shown + ")";
  return name || shown || "Unknown";
}

module.exports = {
  name: "viewonce",
  aliases: ["vv", "vv2", "rvo", "readvo", "readviewonce"],
  category: "owner",
  ownerOnly: true,
  description: "Reveal view-once photos/videos/voice notes with the sender's name — .vv → your DM | .vv2 → this chat",
  usage: ".vv (reply to a view-once) | .vv2 (reply to show it here)",
  extractViewOnce,
  async execute(sock, message, args, context) {
    const chat = context.from || message.key.remoteJid;
    const selfJid = jidNormalizedUser(sock.user?.id || "");
    const here = context.command === "vv2";
    const destination = here ? chat : selfJid;
    const tell = text => sock.sendMessage(chat, { text }, { quoted: message });
    try {
      const ctxInfo = message.message?.extendedTextMessage?.contextInfo || message.message?.stickerMessage?.contextInfo || message.message?.imageMessage?.contextInfo || message.message?.videoMessage?.contextInfo || message.message?.buttonsResponseMessage?.contextInfo || message.message?.listResponseMessage?.contextInfo;
      if (!ctxInfo?.quotedMessage && !ctxInfo?.stanzaId) {
        return await tell(here ? "🗑️ Reply to a *view-once* message with *.vv2* to reveal it here." : "🗑️ Reply to a *view-once* message with *.vv* to reveal it in your DM.");
      }
      const stanzaId = ctxInfo.stanzaId;

      // 1) the full original captured when it arrived, 2) the message store, 3) the quoted copy.
      let original = null;
      const cached = stanzaId ? voCache.get(stanzaId) : null;
      if (cached?.msg) original = cached.msg;
      if (!original && stanzaId && sock.botStore?.loadMessage) {
        const jids = [ctxInfo.remoteJid, chat, message.key.remoteJid, message.key.remoteJidAlt].filter(Boolean);
        for (const jid of jids) {
          const found = await sock.botStore.loadMessage(jid, stanzaId).catch(() => null);
          if (found?.message) { original = found; break; }
        }
      }
      let found = original ? extractViewOnce(original.message) : null;
      if (!found && ctxInfo.quotedMessage) found = extractViewOnce(ctxInfo.quotedMessage);
      if (!found) {
        return await tell("❌ That is not a view-once message, or it is too old for me to open.");
      }

      await sock.sendMessage(chat, { react: { text: "⌛", key: message.key } }).catch(() => {});
      const buffer = await toBuffer(found.media, found.dlType);
      const sender = describeSender(sock, original, ctxInfo, chat);
      const originalCaption = found.media.caption ? "\n\n" + found.media.caption : "";
      const label = found.type === "imageMessage" ? "🖼️ *ViewOnce Image*" : found.type === "videoMessage" ? "🎬 *ViewOnce Video*" : "🎙️ *ViewOnce Audio*";
      const caption = label + "\n👤 *From:* " + sender + originalCaption;

      if (found.type === "imageMessage") {
        await sock.sendMessage(destination, { image: buffer, caption });
      } else if (found.type === "videoMessage") {
        await sock.sendMessage(destination, { video: buffer, caption, mimetype: "video/mp4" });
      } else {
        await sock.sendMessage(destination, { text: caption });
        await sock.sendMessage(destination, { audio: buffer, mimetype: found.media.mimetype || "audio/mp4", ptt: !!found.media.ptt });
      }
      await sock.sendMessage(chat, { react: { text: "✅", key: message.key } }).catch(() => {});
    } catch (error) {
      console.error("[VV]", error.message);
      await tell("❌ Failed to reveal view-once: " + (error.message || "Unknown error")).catch(() => {});
    }
  }
};
