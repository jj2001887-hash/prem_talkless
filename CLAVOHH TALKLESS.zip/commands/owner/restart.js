"use strict";

const RESTART_DELAY_MS = 1500;
const RESTART_EXIT_CODE = 1;

module.exports = {
  name: "restart",
  aliases: ["reboot"],
  category: "owner",
  description: "Safely restart the bot after flushing active resources.",
  ownerOnly: true,
  async execute(value1, value2, value3, { reply: value4 }) {
    if (global._restartRequested) {
      await value4("⏳ *Restart already scheduled*\n\nTALKLESS XMD is already preparing a safe restart.\n\n> BY TALKLESS");
      return;
    }

    global._restartRequested = true;

    try {
      await value4("🔄 *Restart scheduled*\n\nTALKLESS XMD is restarting safely. Active connections, timers, and database changes will be closed first.\n\n> BY TALKLESS");
    } catch (error1) {
      global._restartRequested = false;
      throw error1;
    }

    setTimeout(async () => {
      try {
        if (typeof global.__JUNE_SHUTDOWN === "function") {
          await global.__JUNE_SHUTDOWN();
        } else {
          console.warn("[ RESTART ] No graceful shutdown routine registered; exiting for supervisor restart.");
        }
      } catch (error2) {
        console.error("[ RESTART ] Graceful shutdown failed; exiting for supervisor restart:", error2.message);
      } finally {
        process.exit(RESTART_EXIT_CODE);
      }
    }, RESTART_DELAY_MS);
  }
};

module.exports.RESTART_DELAY_MS = RESTART_DELAY_MS;
module.exports.RESTART_EXIT_CODE = RESTART_EXIT_CODE;
