const {
  loadSettings,
  saveSettings
} = require("../../database");
module.exports = {
  name: "autoviewstatus",
  aliases: ["autostatusview", "asv", "viewstatus", "statusview"],
  category: "owner",
  description: "Auto-view WhatsApp statuses",
  usage: ".autoviewstatus <on/off/get>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = loadSettings();
      const value6 = (value3[0] || "").toLowerCase();
      if (!value6) {
        return value4.reply("👁️ *AUTO VIEW STATUS*\n\nStatus: " + (value5.enabled ? "✅ ON" : "❌ OFF") + "\n\nCommands:\n`.autoviewstatus on`\n`.autoviewstatus off`\n`.autoviewstatus get`");
      }
      if (value6 === "on") {
        value5.enabled = true;
        saveSettings(value5);
        return value4.reply("✅ *AUTO VIEW STATUS ON*\n\nTALKLESS XMD will view new statuses.");
      }
      if (value6 === "off") {
        value5.enabled = false;
        saveSettings(value5);
        return value4.reply("❌ *AUTO VIEW STATUS OFF*\n\nTALKLESS XMD will no longer view new statuses.");
      }
      if (value6 === "get") {
        return value4.reply("👁️ *AUTO VIEW STATUS*\n\nStatus: " + (value5.enabled ? "✅ ON" : "❌ OFF"));
      }
      return value4.reply("⚠️ Use `.autoviewstatus on`, `.autoviewstatus off`, or `.autoviewstatus get`.");
    } catch (error7) {
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
