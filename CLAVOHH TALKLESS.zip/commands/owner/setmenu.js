const database = require("../../database");

function box(value1) {
  return "╭─✦ *Menu Settings* ✦\n" + value1.join("\n") + "\n╰─✦";
}

module.exports = {
  name: "setmenu",
  aliases: ["menustyle", "menuset"],
  category: "owner",
  description: "Show the fixed menu configuration",
  usage: ".setmenu",
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(value1, value2, value3, value4) {
    const value5 = database.getBotSetting("prefix") || ".";
    return value4.reply(box([
      "✅ *Menu style is fixed.*",
      "",
      "The menu always uses the TALKLESS layout with:",
      "• Menu image and menu text together",
      "• Website and ping buttons together",
      "• Audio sent after the menu",
      "",
      "No alternate menu styles are available.",
      "Use *" + value5 + "menu* to open it."
    ]));
  }
};
