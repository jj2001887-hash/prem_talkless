const {
  loadSettings,
  saveSettings
} = require("../../database");
module.exports = {
  name: "autolikestatus",
  aliases: ["autostatusreact", "statusreact", "asr"],
  category: "owner",
  description: "Auto-react to WhatsApp statuses",
  usage: ".autolikestatus <on/off/get>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = loadSettings();
      const value6 = (value3[0] || "").toLowerCase();
      if (!value6) {
        return value4.reply("💙 *AUTO LIKE STATUS*\n\nStatus: " + (value5.react ? "✅ ON" : "❌ OFF") + "\n\nCommands:\n`.autolikestatus on`\n`.autolikestatus off`\n`.autolikestatus get`");
      }
      if (value6 === "on") {
        value5.react = true;
        saveSettings(value5);
        const value7 = value5.randomEmoji && value5.emojiPool.length ? "🎲 Random pool: " + value5.emojiPool.join("  ") : "Emoji: " + value5.emoji;
        return value4.reply("✅ *AUTO LIKE STATUS ON*\n\nTALKLESS XMD will react to new statuses.\n" + value7);
      }
      if (value6 === "off") {
        value5.react = false;
        saveSettings(value5);
        return value4.reply("❌ *AUTO LIKE STATUS OFF*\n\nTALKLESS XMD will no longer react to new statuses.");
      }
      if (value6 === "get") {
        return value4.reply("💙 *AUTO LIKE STATUS*\n\nStatus: " + (value5.react ? "✅ ON" : "❌ OFF"));
      }
      return value4.reply("⚠️ Use `.autolikestatus on`, `.autolikestatus off`, or `.autolikestatus get`.");
    } catch (error8) {
      await value4.reply("❌ Error: " + error8.message);
    }
  }
};
