"use strict";

const {
  searchMovies,
  trendingMovies,
  movieDetails,
  searchShows,
  officialVideoSearch,
  movieWatchOptions,
  formatResults,
  formatDetails,
  formatWatchOptions
} = require("../../utils/movieApi");

function jid(message) {
  return message.key.remoteJid;
}

async function send(sock, message, text) {
  return sock.sendMessage(jid(message), { text }, { quoted: message });
}

async function react(sock, message, text) {
  try {
    await sock.sendMessage(jid(message), { react: { text, key: message.key } });
  } catch {}
}

async function runSearch(sock, message, args, fn, heading) {
  const query = args.join(" ").trim();
  if (!query) return send(sock, message, `🔎 *${heading}*\n\nPlease provide a title.\n\nExample: .${heading.toLowerCase().replace(/\s+/g, "")} Avatar\n\n> BY TALKLESS`);
  await react(sock, message, "⌛");
  try {
    const results = await fn(query);
    await react(sock, message, "✅");
    return send(sock, message, formatResults(results, `${heading}: ${query}`));
  } catch (error) {
    await react(sock, message, "🚫");
    console.error(`[MOVIES] ${heading}:`, error.message);
    return send(sock, message, "❌ *Movie service unavailable*\n\nPlease try again shortly.\n\n> BY TALKLESS");
  }
}

async function runDetails(sock, message, args) {
  const query = args.join(" ").trim();
  if (!query) return send(sock, message, "🎬 *Movie details*\n\nUsage: .moviedetail <title or TMDB ID>\n\n> BY TALKLESS");
  await react(sock, message, "⌛");
  try {
    const result = await movieDetails(query);
    await react(sock, message, "✅");
    return send(sock, message, formatDetails(result));
  } catch (error) {
    await react(sock, message, "🚫");
    console.error("[MOVIES] details:", error.message);
    return send(sock, message, "❌ *Movie not found*\n\nTry the title or use .moviesearch first.\n\n> BY TALKLESS");
  }
}

async function runTrailer(sock, message, args, kind = "trailer") {
  const query = args.join(" ").trim();
  if (!query) return send(sock, message, `▶️ *Official ${kind}*\n\nUsage: .${kind === "music video" ? "musicvideo" : "trailer"} <title>\n\n> BY TALKLESS`);
  await react(sock, message, "⌛");
  try {
    const results = await officialVideoSearch(query, kind);
    if (!results.length) throw new Error("No official video found");
    const text = `▶️ *${kind === "music video" ? "Music video" : "Official trailer"}: ${query}*\n\n` + results.map((item, index) => `${index + 1}. *${item.title}*\n   🎤 ${item.author} • ⏱ ${item.duration}\n   🔗 ${item.url}`).join("\n\n") + "\n\n> BY TALKLESS";
    await react(sock, message, "✅");
    return send(sock, message, text);
  } catch (error) {
    await react(sock, message, "🚫");
    console.error("[MOVIES] official video:", error.message);
    return send(sock, message, "❌ *Official video not found*\n\nTry another title.\n\n> BY TALKLESS");
  }
}

async function runWatch(sock, message, args) {
  const query = args.join(" ").trim();
  if (!query) return send(sock, message, "📺 *Where to watch a movie*\n\nUsage: .watchmovie <title>\n\n> BY TALKLESS");
  await react(sock, message, "⌛");
  try {
    const options = await movieWatchOptions(query, process.env.TMDB_REGION || "US");
    await react(sock, message, "✅");
    return send(sock, message, formatWatchOptions(options));
  } catch (error) {
    await react(sock, message, "🚫");
    console.error("[MOVIES] watch options:", error.message);
    return send(sock, message, "❌ *Movie source lookup failed*\n\nTry the title again or use .moviesearch first.\n\n> BY TALKLESS");
  }
}

module.exports = [
  {
    name: "moviesearch",
    aliases: ["iboxmoviesearch", "searchmovie", "movie"],
    category: "movies",
    description: "Search movies using TMDB or IMDb fallback.",
    usage: ".moviesearch <title>",
    execute: (sock, message, args) => runSearch(sock, message, args, searchMovies, "Movie search")
  },
  {
    name: "iboxmovies",
    aliases: ["movietrending", "latestmovies", "trendingmovies"],
    category: "movies",
    description: "Show trending movies.",
    usage: ".iboxmovies",
    execute: async (sock, message) => {
      await react(sock, message, "⌛");
      try {
        const results = await trendingMovies();
        await react(sock, message, "✅");
        return send(sock, message, formatResults(results, "Trending movies"));
      } catch (error) {
        await react(sock, message, "🚫");
        return send(sock, message, "❌ *Movie service unavailable*\n\n> BY TALKLESS");
      }
    }
  },
  {
    name: "moviedetail",
    aliases: ["iboxmoviedetail", "movieinfo"],
    category: "movies",
    description: "Show movie details.",
    usage: ".moviedetail <title or TMDB ID>",
    execute: runDetails
  },
  {
    name: "moviebox",
    aliases: ["mbsearch", "mbmovie"],
    category: "movies",
    description: "Search movies and return legal metadata links.",
    usage: ".moviebox <title>",
    execute: (sock, message, args) => runSearch(sock, message, args, searchMovies, "Movie search")
  },
  {
    name: "watchmovie",
    aliases: ["watch", "streammovie", "moviewatch"],
    category: "movies",
    description: "Find official streaming, rent, or purchase options for a movie.",
    usage: ".watchmovie <title>",
    execute: runWatch
  },
  {
    name: "moviedownload",
    aliases: ["downloadmovie", "dlmovie"],
    category: "movies",
    description: "Find official movie providers; no unauthorized movie files are downloaded.",
    usage: ".moviedownload <title>",
    execute: runWatch
  },
  {
    name: "trailer",
    aliases: ["movietrailer", "gettrailer"],
    category: "movies",
    description: "Find official movie trailers on YouTube.",
    usage: ".trailer <title>",
    execute: (sock, message, args) => runTrailer(sock, message, args, "trailer")
  },
  {
    name: "moviedl",
    aliases: ["trailerdownload", "dltrailer"],
    category: "movies",
    description: "Get an official movie trailer link.",
    usage: ".moviedl <title>",
    execute: (sock, message, args) => runTrailer(sock, message, args, "trailer")
  },
  {
    name: "tvsearch",
    aliases: ["iboxsearch", "searchtv"],
    category: "movies",
    description: "Search TV shows using TMDB or TVMaze fallback.",
    usage: ".tvsearch <title>",
    execute: (sock, message, args) => runSearch(sock, message, args, searchShows, "TV search")
  },
  {
    name: "iboxtv",
    aliases: ["tvtrending", "tvshows"],
    category: "movies",
    description: "Search TV shows using the working TV provider.",
    usage: ".iboxtv <title>",
    execute: (sock, message, args) => runSearch(sock, message, args.length ? args : ["popular"], searchShows, "TV search")
  },
  {
    name: "tvdetail",
    aliases: ["iboxtvdetail", "showdetail"],
    category: "movies",
    description: "Search a TV show and show its details.",
    usage: ".tvdetail <title>",
    execute: (sock, message, args) => runSearch(sock, message, args, searchShows, "TV details")
  },
  {
    name: "actor",
    aliases: ["actorsearch", "findactor"],
    category: "movies",
    description: "Search a person through movie results.",
    usage: ".actor <name>",
    execute: (sock, message, args) => runSearch(sock, message, args, searchMovies, "Actor search")
  },
  {
    name: "dramabox",
    aliases: ["drama", "dramastream"],
    category: "movies",
    description: "Search legal movie and show information.",
    usage: ".dramabox <title>",
    execute: (sock, message, args) => runSearch(sock, message, args, searchShows, "Drama search")
  },
  {
    name: "iboxanime",
    aliases: ["animetrending", "latestanime"],
    category: "movies",
    description: "Search anime information from the movies category.",
    usage: ".iboxanime <title>",
    execute: (sock, message, args) => runSearch(sock, message, args, searchShows, "Anime search")
  },
  {
    name: "animedetail",
    aliases: ["iboxanimedetail"],
    category: "movies",
    description: "Search anime information.",
    usage: ".animedetail <title>",
    execute: (sock, message, args) => runSearch(sock, message, args, searchShows, "Anime details")
  },
  {
    name: "animesearch",
    aliases: ["iboxanimesearch", "searchanime"],
    category: "movies",
    description: "Search anime information.",
    usage: ".animesearch <title>",
    execute: (sock, message, args) => runSearch(sock, message, args, searchShows, "Anime search")
  }
];
