const {
  randomPickup
} = require("../../utils/funApi");
module.exports = {
  name: "pickupline",
  aliases: ["rizz"],
  category: "fun",
  description: "Get a random pickup line",
  usage: ".pickupline",
  async execute(value1, value2, value3, value4) {
    await value4.react("⌛");
    try {
      const value6 = await randomPickup();
      await value4.reply("😏 *Pickup Line*\n\n_" + value6 + "_");
    } catch (error7) {
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
