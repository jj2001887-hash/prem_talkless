const {
  randomQuote
} = require("../../utils/funApi");
module.exports = {
  name: "quotes",
  aliases: ["quote"],
  category: "fun",
  description: "Get a random fact or quote",
  usage: ".fact",
  async execute(value1, value2, value3, value4) {
    await value4.react("⌛");
    try {
      const value5 = await randomQuote();
      await value4.reply("💬 *Random Quote*\n\n_" + value5.text + "_\n\n— " + value5.author);
      await value4.react("✅");
    } catch (error6) {
      await value4.react("🚫");
      await value4.reply("❌ Error: " + error6.message);
    }
  }
};
