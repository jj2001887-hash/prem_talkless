const {
  randomParanoia
} = require("../../utils/funApi");
module.exports = {
  name: "paranoia",
  aliases: [],
  category: "fun",
  description: "Get a random paranoia question",
  usage: ".paranoia",
  async execute(value1, value2, value3, value4) {
    await value4.react("⌛");
    try {
      const value6 = await randomParanoia();
      await value4.reply("😱 *Paranoia*\n\n_" + value6 + "_");
    } catch (error7) {
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
