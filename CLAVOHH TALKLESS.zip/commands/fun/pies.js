"use strict";

const axios = require("axios");
const database = require("../../database");
const VALID_COUNTRIES = ["india", "malaysia", "thailand", "china", "indonesia", "japan", "korea", "vietnam"];
const COUNTRY_SUBREDDITS = {
  india: "IndiaSpeaks",
  malaysia: "malaysia",
  thailand: "Thailand",
  china: "China",
  indonesia: "indonesia",
  japan: "japan",
  korea: "korea"
};
async function getImage(value1) {
  const value2 = COUNTRY_SUBREDDITS[value1];
  if (value2) {
    try {
      const value3 = await axios.get("https://meme-api.com/gimme/" + encodeURIComponent(value2), {
        timeout: 10000,
        headers: {
          "User-Agent": "TALKLESS-XMD/4.0"
        }
      });
      if (value3.data?.url) {
        return {
          url: value3.data.url,
          title: value3.data.title || value1
        };
      }
    } catch {}
  }
  const value4 = await axios.get("https://meme-api.com/gimme", {
    timeout: 10000,
    headers: {
      "User-Agent": "TALKLESS-XMD/4.0"
    }
  });
  if (!value4.data?.url) {
    throw new Error("No image result was returned");
  }
  return {
    url: value4.data.url,
    title: value4.data.title || value1
  };
}
module.exports = {
  name: "pies",
  aliases: ["pie", ...VALID_COUNTRIES],
  category: "fun",
  description: "Get a random country-themed image",
  usage: "pies <country>",
  async execute(value1, value2, value3, value4) {
    const value5 = database.getBotSetting("prefix") || ".";
    const value6 = String(value3[0] || "").toLowerCase().trim();
    if (!value6) {
      return value4.reply("🖼️ *Country Image*\n\nUsage: " + value5 + "pies <country>\n\nCountries: " + VALID_COUNTRIES.join(", "));
    }
    if (!VALID_COUNTRIES.includes(value6)) {
      return value4.reply("❌ Unsupported country: " + value6 + "\n\nTry: " + VALID_COUNTRIES.join(", "));
    }
    try {
      const value7 = await getImage(value6);
      const value8 = await axios.get(value7.url, {
        responseType: "arraybuffer",
        timeout: 15000,
        maxContentLength: 8388608,
        headers: {
          "User-Agent": "TALKLESS-XMD/4.0"
        }
      });
      const value9 = value8.headers["content-type"] || "";
      if (!value9.startsWith("image/")) {
        throw new Error("The image source returned an unsupported file");
      }
      await value1.sendMessage(value4.from, {
        image: Buffer.from(value8.data),
        caption: "🖼️ *" + value7.title + "*\n🌍 Country: " + value6 + "\n\n> BY TALKLESS"
      }, {
        quoted: value2
      });
    } catch (error10) {
      console.error("[pies] image error:", error10.message);
      await value4.reply("❌ *Image service unavailable*\n\nTry again shortly.");
    }
  }
};
