const {
  randomFact
} = require("../../utils/funApi");
module.exports = {
  name: "fact",
  aliases: ["randomfact"],
  category: "fun",
  description: "Get a random fact or quote",
  usage: ".fact",
  async execute(value1, value2, value3, value4) {
    await value4.react("⌛");
    try {
      const value5 = await randomFact();
      await value4.reply("💡 *Random Fact*\n\n_" + value5 + "_");
      await value4.react("✅");
    } catch (error6) {
      await value4.react("🚫");
      await value4.reply("❌ Error: " + error6.message);
    }
  }
};
