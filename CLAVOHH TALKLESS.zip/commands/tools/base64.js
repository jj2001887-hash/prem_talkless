function footer(text) {
  return text + "\n\n> BY TALKLESS";
}

function cleanInput(value) {
  return value.replace(/^`|`$/g, "").trim();
}

module.exports = [{
  name: "base64encode",
  aliases: ["b64encode", "encode64"],
  category: "tools",
  description: "Encode text as Base64",
  usage: ".base64encode <text>",
  async execute(sock, msg, args, command) {
    const input = cleanInput(args.join(" "));
    if (!input) {
      return command.reply(footer("❌ Provide text to encode.\n\nExample: *.base64encode hello world*"));
    }
    const encoded = Buffer.from(input, "utf8").toString("base64");
    await command.reply(footer("🔐 *BASE64 ENCODE*\n\n📝 Input: " + input + "\n✅ Output:\n`" + encoded + "`"));
  }
}, {
  name: "base64decode",
  aliases: ["b64decode", "decode64"],
  category: "tools",
  description: "Decode Base64 text",
  usage: ".base64decode <Base64 text>",
  async execute(sock, msg, args, command) {
    const input = cleanInput(args.join(""));
    if (!input || !/^[A-Za-z0-9+/]+={0,2}$/.test(input) || input.length % 4 !== 0) {
      return command.reply(footer("❌ Provide valid Base64 text.\n\nExample: *.base64decode aGVsbG8=*"));
    }
    const decoded = Buffer.from(input, "base64").toString("utf8");
    if (!decoded || decoded.includes("\uFFFD")) {
      return command.reply(footer("❌ The Base64 value could not be decoded as readable text."));
    }
    await command.reply(footer("🔓 *BASE64 DECODE*\n\n📝 Input: `" + input + "`\n✅ Output:\n" + decoded));
  }
}];
