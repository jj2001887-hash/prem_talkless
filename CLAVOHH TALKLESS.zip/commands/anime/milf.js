const { sendAnimeImage, sendAnimeError } = require("../../utils/animeApi");

module.exports = {
  name: "milf",
  aliases: ["milfnsfw"],
  category: "anime",
  description: "Get a random NSFW anime image.",
  usage: ".milf",
  async execute(value1, value2, value3, value4) {
    try {
      await sendAnimeImage(value1, value2, value4, {
        tag: "waifu",
        nsfw: true,
        caption: "🔞 *Random NSFW anime image*\n\n> BY TALKLESS"
      });
    } catch (error) {
      await sendAnimeError(value4, "milf", error);
    }
  }
};
