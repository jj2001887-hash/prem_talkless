const { sendAnimeImage, sendAnimeError } = require("../../utils/animeApi");

module.exports = {
  name: "konachan",
  aliases: ["konachansfw"],
  category: "anime",
  description: "Get a random SFW anime image.",
  usage: ".konachan",
  async execute(value1, value2, value3, value4) {
    try {
      await sendAnimeImage(value1, value2, value4, {
        tag: "waifu",
        caption: "🎨 *Random anime art*\n\n> BY TALKLESS"
      });
    } catch (error) {
      await sendAnimeError(value4, "konachan", error);
    }
  }
};
