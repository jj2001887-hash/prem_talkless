const { getRandomAnime, formatAnime, sendAnimeError } = require("../../utils/animeApi");

module.exports = {
  name: "random",
  aliases: ["animerandom", "randomanime"],
  category: "anime",
  description: "Get a random anime with current metadata.",
  usage: ".random",
  async execute(value1, value2, value3, value4) {
    try {
      const anime = await getRandomAnime();
      const text = formatAnime(anime);
      if (anime.image) {
        await value1.sendMessage(value4.from || value2.key.remoteJid, {
          image: { url: anime.image },
          caption: text
        }, { quoted: value2 });
      } else {
        await value4.reply(text);
      }
    } catch (error) {
      await sendAnimeError(value4, "random", error);
    }
  }
};
