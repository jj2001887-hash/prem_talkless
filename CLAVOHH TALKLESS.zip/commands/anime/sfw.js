const { sendAnimeImage, sendAnimeError } = require("../../utils/animeApi");

function imageCommand(name, aliases, tag, caption) {
  return {
    name,
    aliases,
    category: "anime",
    description: `Get a random ${name} anime image.`,
    usage: `.${name}`,
    async execute(value1, value2, value3, value4) {
      try {
        await sendAnimeImage(value1, value2, value4, { tag, caption });
      } catch (error) {
        await sendAnimeError(value4, name, error);
      }
    }
  };
}

module.exports = [
  imageCommand("waifu", ["randomwaifu"], "waifu", "✨ *Random waifu*\n\n> BY TALKLESS"),
  imageCommand("neko", ["catgirl", "nekogirl"], "neko", "🐱 *Random neko*\n\n> BY TALKLESS"),
  imageCommand("loli", ["animeloli"], "waifu", "🌸 *Random anime character*\n\n> BY TALKLESS"),
  imageCommand("shota", ["animeshota"], "waifu", "🎴 *Random anime character*\n\n> BY TALKLESS"),
  imageCommand("husby", ["husband", "husbando"], "waifu", "💙 *Random husbando*\n\n> BY TALKLESS")
];
