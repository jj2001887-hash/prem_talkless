const { sendAnimeImage, sendAnimeError } = require("../../utils/animeApi");

module.exports = {
  name: "megumin",
  aliases: ["meguminnsfw"],
  category: "anime",
  description: "Get a random Megumin anime image.",
  usage: ".megumin",
  async execute(value1, value2, value3, value4) {
    try {
      await sendAnimeImage(value1, value2, value4, {
        tag: "megumin",
        caption: "💥 *Random Megumin*\n\n> BY TALKLESS"
      });
    } catch (error) {
      await sendAnimeError(value4, "megumin", error);
    }
  }
};
