const { sendAnimeImage, sendAnimeError } = require("../../utils/animeApi");

module.exports = {
  name: "hwaifu",
  aliases: ["hwaifunsfw"],
  category: "anime",
  description: "Get a random NSFW anime waifu image.",
  usage: ".hwaifu",
  async execute(value1, value2, value3, value4) {
    try {
      await sendAnimeImage(value1, value2, value4, {
        tag: "waifu",
        nsfw: true,
        caption: "🔞 *Random NSFW waifu*\n\n> BY TALKLESS"
      });
    } catch (error) {
      await sendAnimeError(value4, "hwaifu", error);
    }
  }
};
