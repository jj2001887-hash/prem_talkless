const { sendAnimeImage, sendAnimeError } = require("../../utils/animeApi");

module.exports = {
  name: "hneko",
  aliases: ["hnekonsfw"],
  category: "anime",
  description: "Get a random NSFW anime neko image.",
  usage: ".hneko",
  async execute(value1, value2, value3, value4) {
    try {
      await sendAnimeImage(value1, value2, value4, {
        tag: "neko",
        nsfw: true,
        caption: "🔞 *Random NSFW neko*\n\n> BY TALKLESS"
      });
    } catch (error) {
      await sendAnimeError(value4, "hneko", error);
    }
  }
};
