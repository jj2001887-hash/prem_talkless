'use strict';

const axios = require('axios');

const client = axios.create({
  timeout: 8000,
  headers: {
    'User-Agent': 'TALKLESS-XMD/4.0',
    Accept: 'application/json, text/plain, */*'
  }
});

const DATA = {
  facts: [
    'Honey never spoils when it is stored properly.',
    'Octopuses have three hearts.',
    'A group of flamingos is called a flamboyance.',
    'Bananas are berries, but strawberries are not botanically berries.',
    'The fingerprints of a koala are very similar to human fingerprints.',
    'The shortest war in history lasted about 38 minutes.',
    'A day on Venus is longer than a year on Venus.',
    'Sea otters hold hands while sleeping so they do not drift apart.'
  ],
  quotes: [
    ['The secret of getting ahead is getting started.', 'Mark Twain'],
    ['Great things are done by a series of small things brought together.', 'Vincent van Gogh'],
    ['It always seems impossible until it is done.', 'Nelson Mandela'],
    ['Do what you can, with what you have, where you are.', 'Theodore Roosevelt'],
    ['Success is the sum of small efforts, repeated day in and day out.', 'Robert Collier']
  ],
  flirt: [
    'Are you a keyboard? You are just my type.',
    'If smiles were stars, you would light up the whole sky.',
    'I was going to wait for the perfect line, but then I saw you.',
    'You must be a good song, because I cannot get you out of my head.'
  ],
  pickup: [
    'Are you made of copper and tellurium? Because you are Cu-Te.',
    'If you were a playlist, you would be my favorite track.',
    'Do you have a map? I keep getting lost in your smile.',
    'You must be a camera, because every time I see you I smile.'
  ],
  paranoia: [
    'What is the most embarrassing thing you have done in public?',
    'Who in this chat would survive the longest in a zombie apocalypse?',
    'What is a secret you have never told your closest friend?',
    'What is the strangest coincidence that has happened to you?'
  ],
  wyr: [
    'Would you rather always be ten minutes late or always be twenty minutes early?',
    'Would you rather have the ability to fly or become invisible?',
    'Would you rather explore the ocean or explore outer space?',
    'Would you rather never use social media again or never watch movies again?'
  ]
};

function pick(items) {
  return items[Math.floor(Math.random() * items.length)];
}

async function request(url, options = {}) {
  const response = await client.get(url, options);
  return response.data;
}

async function randomFact() {
  try {
    const data = await request('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en');
    if (data?.text) return data.text;
  } catch {}
  return pick(DATA.facts);
}

async function randomQuote() {
  try {
    const data = await request('https://zenquotes.io/api/random');
    const item = Array.isArray(data) ? data[0] : data;
    if (item?.q) return { text: item.q, author: item.a || 'Unknown' };
  } catch {}
  const [text, author] = pick(DATA.quotes);
  return { text, author };
}

async function randomText(kind) {
  const endpoint = {
    flirt: 'https://api.popcat.xyz/pickuplines',
    pickup: 'https://api.popcat.xyz/pickuplines',
    paranoia: 'https://api.truthordarebot.xyz/v1/paranoia',
    wyr: 'https://api.truthordarebot.xyz/v1/wyr'
  }[kind];
  if (endpoint) {
    try {
      const data = await request(endpoint);
      const text = typeof data === 'string' ? data : data?.question || data?.line || data?.pickup || data?.result;
      if (typeof text === 'string' && text.trim()) return text.trim();
    } catch {}
  }
  return pick(DATA[kind]);
}

module.exports = {
  randomFact,
  randomQuote,
  randomFlirt: () => randomText('flirt'),
  randomPickup: () => randomText('pickup'),
  randomParanoia: () => randomText('paranoia'),
  randomWouldYouRather: () => randomText('wyr'),
  _data: DATA
};
