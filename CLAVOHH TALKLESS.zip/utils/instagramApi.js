"use strict";

const axios = require("axios");
const FormData = require("form-data");
const { instagram: jerryCoderInstagram } = require("@jerrycoder/instagram-api");
const { dedupe, createTtlCache } = require("./fastMedia");

const REQUEST_TIMEOUT_MS = Math.max(5000, Math.min(10000, Number(process.env.INSTAGRAM_API_TIMEOUT_MS) || 7000));
const cache = createTtlCache({ ttlMs: 120000, maxEntries: 100 });
const USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36";

function withTimeout(task, ms = REQUEST_TIMEOUT_MS) {
  let timer;
  return Promise.race([
    Promise.resolve().then(task),
    new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("Instagram provider timeout")), ms); })
  ]).finally(() => clearTimeout(timer));
}

function extractInstagramUrl(text) {
  const match = String(text || "").match(/https?:\/\/(?:www\.)?(?:instagram\.com|instagr\.am)\/[^\s<>]+/i);
  return match ? match[0].replace(/[),.!?]+$/, "") : null;
}

function mediaUrl(value) {
  if (typeof value === "string" && /^https?:\/\//i.test(value)) return value;
  if (!value || typeof value !== "object") return null;
  for (const key of ["downloadUrl", "download_url", "url", "original", "mediaUrl", "videoUrl", "imageUrl", "src"]) {
    const candidate = value[key];
    if (typeof candidate === "string" && /^https?:\/\//i.test(candidate)) return candidate;
  }
  return null;
}

function flattenMedia(value, output = []) {
  if (!value) return output;
  if (typeof value === "string") {
    if (mediaUrl(value)) output.push({ url: value });
    return output;
  }
  if (Array.isArray(value)) {
    for (const item of value) flattenMedia(item, output);
    return output;
  }
  if (typeof value === "object") {
    const url = mediaUrl(value);
    if (url) output.push({ ...value, url });
    for (const key of ["data", "result", "results", "items", "medias", "media", "videos", "images", "urls"]) {
      if (value[key]) flattenMedia(value[key], output);
    }
  }
  return output;
}

function normalizeMedia(value) {
  const seen = new Set();
  return flattenMedia(value).filter(item => {
    if (!item.url || seen.has(item.url)) return false;
    seen.add(item.url);
    return true;
  }).map(item => ({
    ...item,
    type: String(item.type || item.kind || "").toLowerCase() === "video" || /\.(mp4|mov|webm)(?:[?#]|$)/i.test(item.url) ? "video" : "image"
  }));
}

async function directPageProvider(url) {
  const response = await axios.get(url, {
    timeout: 6000,
    maxRedirects: 4,
    responseType: "text",
    headers: { "User-Agent": USER_AGENT, Accept: "text/html,application/xhtml+xml" }
  });
  const html = String(response.data || "");
  const found = [];
  const add = (value, type) => {
    if (typeof value !== "string") return;
    const decoded = value.replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/&amp;/g, "&");
    if (/^https?:\/\//i.test(decoded)) found.push({ url: decoded, type });
  };
  for (const match of html.matchAll(/<meta[^>]+(?:property|name)=["'](?:og:(?:video|image)|twitter:image)["'][^>]+content=["']([^"']+)["']/gi)) {
    add(match[1], /og:video/i.test(match[0]) ? "video" : "image");
  }
  for (const match of html.matchAll(/(?:\"video_url\"|\"display_url\")\s*:\s*\"([^\"]+)/g)) {
    add(match[1], /video_url/.test(match[0]) ? "video" : "image");
  }
  const media = normalizeMedia(found);
  if (!media.length) throw new Error("Instagram page did not expose public media");
  return { data: media, provider: "instagram-page" };
}

async function configurableProvider(url) {
  const endpoint = String(process.env.INSTAGRAM_API_URL || "").trim();
  if (!endpoint) throw new Error("INSTAGRAM_API_URL is not configured");
  const method = String(process.env.INSTAGRAM_API_METHOD || "GET").toUpperCase();
  const target = endpoint.includes("{url}") ? endpoint.replaceAll("{url}", encodeURIComponent(url)) : endpoint;
  const response = await axios.request({
    url: target,
    method,
    params: target === endpoint && method === "GET" ? { url } : undefined,
    data: target === endpoint && method === "POST" ? { url } : undefined,
    timeout: REQUEST_TIMEOUT_MS,
    headers: { "User-Agent": USER_AGENT, Accept: "application/json" }
  });
  const data = normalizeMedia(response.data);
  if (!data.length) throw new Error("Configured Instagram API returned no media");
  return { data, provider: "configured" };
}

async function rapidApiProvider(url) {
  const key = String(process.env.RAPIDAPI_KEY || process.env.INSTAGRAM_RAPIDAPI_KEY || "").trim();
  if (!key) throw new Error("RapidAPI key is not configured");
  const form = new FormData();
  form.append("url", url);
  const response = await axios.post("https://instagram-downloader51.p.rapidapi.com/download.php", form, {
    timeout: REQUEST_TIMEOUT_MS,
    headers: { ...form.getHeaders(), "X-RapidAPI-Key": key, "X-RapidAPI-Host": "instagram-downloader51.p.rapidapi.com", "User-Agent": USER_AGENT },
    maxContentLength: Infinity,
    maxBodyLength: Infinity
  });
  const data = normalizeMedia(response.data);
  if (!data.length) throw new Error("RapidAPI returned no media");
  return { data, provider: "rapidapi" };
}

async function resolveInstagramMedia(input) {
  const url = extractInstagramUrl(input) || String(input || "").trim();
  if (!/^https?:\/\/(?:www\.)?(?:instagram\.com|instagr\.am)\//i.test(url)) {
    throw new Error("Invalid Instagram URL");
  }
  const cached = cache.get(url);
  if (cached) return cached;
  return dedupe("instagram:" + url, async () => {
    const providers = [
      () => rapidApiProvider(url),
      () => configurableProvider(url),
      () => jerryCoderInstagram(url, { timeout: 4000 }).then(result => ({ data: normalizeMedia(result), provider: "jerrycoder" })),
      () => directPageProvider(url)
    ];
    if (/^(1|true|yes|on)$/i.test(String(process.env.INSTAGRAM_ENABLE_LEGACY_SCRAPER || ""))) {
      providers.push(() => withTimeout(() => require("ruhend-scraper").igdl(url), 5000).then(result => ({ data: normalizeMedia(result), provider: "ruhend-legacy" })));
    }
    const winner = await Promise.any(providers.map(provider => withTimeout(provider)));
    if (!winner?.data?.length) throw new Error("No public Instagram media found");
    const result = { data: winner.data.slice(0, 20), provider: winner.provider };
    cache.set(url, result);
    return result;
  });
}

module.exports = { extractInstagramUrl, normalizeMedia, resolveInstagramMedia };
