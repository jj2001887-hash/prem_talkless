"use strict";

const axios = require("axios");

const HTTP_TIMEOUT = 20000;
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const USER_AGENT = "TALKLESS-XMD/4.0";

const client = axios.create({
  timeout: HTTP_TIMEOUT,
  headers: {
    "User-Agent": USER_AGENT,
    Accept: "application/json"
  },
  maxContentLength: MAX_IMAGE_BYTES,
  maxBodyLength: MAX_IMAGE_BYTES
});

function cleanUrl(value) {
  if (typeof value !== "string") {
    return null;
  }
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : null;
  } catch (error) {
    return null;
  }
}

function imageUrlFromWaifuIm(data) {
  return cleanUrl(data?.items?.[0]?.url);
}

function imageUrlFromWaifuPics(data) {
  return cleanUrl(data?.url);
}

async function fetchImageUrl(tag = "waifu", nsfw = false) {
  const safeTag = String(tag || "waifu").trim().toLowerCase();
  const waifuIm = new URL("https://api.waifu.im/images");
  waifuIm.searchParams.set("IncludedTags", safeTag);
  waifuIm.searchParams.set("IsNsfw", nsfw ? "True" : "False");

  const requests = [
    async () => imageUrlFromWaifuIm((await client.get(waifuIm.toString())).data),
    async () => {
      const endpoint = nsfw ? "nsfw" : "sfw";
      const supported = nsfw
        ? new Set(["waifu", "neko", "trap", "blowjob"])
        : new Set(["waifu", "neko", "shinobu", "megumin", "cuddle", "cry", "hug", "awoo", "kiss", "lick", "pat", "smug", "bonk", "yeet", "blush", "smile", "wave", "highfive", "handhold", "nom", "bite", "glomp", "slap", "kill", "kick", "happy", "wink"]);
      const fallbackTag = supported.has(safeTag) ? safeTag : "waifu";
      return imageUrlFromWaifuPics((await client.get(`https://api.waifu.pics/${endpoint}/${fallbackTag}`)).data);
    }
  ];

  let lastError = null;
  for (const request of requests) {
    try {
      const url = await request();
      if (url) {
        return url;
      }
      lastError = new Error("The anime image provider returned no image URL.");
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error("Anime image providers are unavailable.");
}

async function downloadImage(url) {
  const response = await client.get(url, {
    responseType: "arraybuffer",
    headers: {
      Accept: "image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8"
    }
  });
  const buffer = Buffer.from(response.data || []);
  const contentType = String(response.headers["content-type"] || "").toLowerCase();
  if (!buffer.length || (!contentType.startsWith("image/") && !/^\x89PNG|^\xff\xd8\xff|^RIFF/.test(buffer.toString("latin1", 0, 4)))) {
    throw new Error("The anime image provider returned an invalid image.");
  }
  if (buffer.length > MAX_IMAGE_BYTES) {
    throw new Error("The anime image is too large to send.");
  }
  return buffer;
}

async function getAnimeImage(tag, nsfw = false) {
  const url = await fetchImageUrl(tag, nsfw);
  return {
    url,
    buffer: await downloadImage(url)
  };
}

function titleOf(anime) {
  return anime?.title?.english || anime?.title?.romaji || anime?.title || "Unknown anime";
}

function normalizeAnime(anime) {
  if (!anime) {
    return null;
  }
  return {
    title: titleOf(anime),
    nativeTitle: anime.title?.native || anime.title_japanese || "",
    episodes: anime.episodes ?? anime.episodes ?? "Unknown",
    status: anime.status || "Unknown",
    score: anime.score || anime.averageScore ? (anime.score || anime.averageScore) : "N/A",
    year: anime.year || anime.seasonYear || anime.aired?.prop?.from?.year || "Unknown",
    genres: Array.isArray(anime.genres) ? anime.genres.map(item => typeof item === "string" ? item : item.name).filter(Boolean) : [],
    synopsis: anime.synopsis || anime.description || "No synopsis available.",
    image: cleanUrl(anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url || anime.coverImage?.extraLarge || anime.coverImage?.large),
    url: cleanUrl(anime.url || anime.siteUrl)
  };
}

async function getRandomAnime() {
  let lastError = null;
  try {
    const data = (await client.get("https://api.jikan.moe/v4/random/anime")).data;
    const anime = normalizeAnime(data?.data);
    if (anime) {
      return anime;
    }
  } catch (error) {
    lastError = error;
  }

  try {
    const query = `query { Page(page: 1, perPage: 25) { media(type: ANIME, sort: TRENDING_DESC, isAdult: false) { title { romaji english native } episodes status averageScore seasonYear description genres coverImage { large extraLarge } siteUrl } } }`;
    const data = (await client.post("https://graphql.anilist.co", { query })).data;
    const list = data?.data?.Page?.media || [];
    if (list.length) {
      return normalizeAnime(list[Math.floor(Math.random() * list.length)]);
    }
  } catch (error) {
    lastError = error;
  }
  throw lastError || new Error("Anime metadata providers are unavailable.");
}

function formatAnime(anime) {
  const genres = anime.genres.length ? anime.genres.join(", ") : "Unknown";
  return `🎬 *${anime.title}*\n\n` +
    `📺 Episodes: ${anime.episodes}\n` +
    `📊 Status: ${anime.status}\n` +
    `⭐ Score: ${anime.score}\n` +
    `📅 Year: ${anime.year}\n` +
    `🏷️ Genres: ${genres}\n\n` +
    `📝 ${String(anime.synopsis).replace(/\s+/g, " ").slice(0, 700)}\n` +
    (anime.url ? `\n🔗 ${anime.url}` : "") +
    "\n\n> BY TALKLESS";
}

async function sendAnimeImage(sock, message, context, options = {}) {
  const image = await getAnimeImage(options.tag || "waifu", Boolean(options.nsfw));
  const destination = context.from || message?.key?.remoteJid;
  await sock.sendMessage(destination, {
    image: image.buffer,
    caption: options.caption || "✨ *Anime image*\n\n> BY TALKLESS"
  }, { quoted: message });
}

async function sendAnimeError(context, name, error) {
  console.error(`[ ANIME ] ${name}:`, error?.message || error);
  await context.reply("❌ *Anime service unavailable*\n\nPlease try again in a moment.\n\n> BY TALKLESS");
}

module.exports = {
  getAnimeImage,
  getRandomAnime,
  formatAnime,
  sendAnimeImage,
  sendAnimeError
};
