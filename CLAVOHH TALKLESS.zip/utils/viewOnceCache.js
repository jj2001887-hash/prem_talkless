"use strict";
// Shared cache of full view-once messages (keyed by message id), filled by the handler
// as messages arrive so that .vv can reveal them even when the quoted copy is stripped.
module.exports = new Map();
