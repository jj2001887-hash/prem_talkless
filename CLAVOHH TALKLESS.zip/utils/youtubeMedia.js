"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { execFileSync, execFile } = require("child_process");
const { promisify } = require("util");
const axios = require("axios");
const execFileAsync = promisify(execFile);
const ytDlpModule = require("yt-dlp-exec");
const resolveFfmpegPath = require("./ffmpegPath");

const MAX_AUDIO_BYTES = 28 * 1024 * 1024;
const MAX_VIDEO_BYTES = 64 * 1024 * 1024;

function resolveYtDlpBinary() {
  const configured = String(process.env.YTDLP_PATH || "").trim();
  if (configured && fs.existsSync(configured)) return configured;
  try {
    const bundled = require("yt-dlp-exec/src/constants").YOUTUBE_DL_PATH;
    if (bundled && fs.existsSync(bundled)) return bundled;
  } catch {}
  try {
    const system = execFileSync("which", ["yt-dlp"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
    if (system && fs.existsSync(system)) return system;
  } catch {}
  return null;
}

function safeName(value, fallback) {
  return (String(value || fallback).replace(/[^\w\s().-]/g, "").trim() || fallback).slice(0, 80);
}

async function downloadYoutube(url, mode = "audio", title = "media") {
  const binary = resolveYtDlpBinary();
  if (!binary && typeof ytDlpModule.create !== "function") throw new Error("yt-dlp is not installed on this host");
  const ytDlp = binary && typeof ytDlpModule.create === "function" ? ytDlpModule.create(binary) : ytDlpModule;
  const base = path.join(os.tmpdir(), `talkless-${mode}-${crypto.randomBytes(8).toString("hex")}`);
  const options = {
    noPlaylist: true,
    retries: 3,
    fragmentRetries: 3,
    extractorRetries: 3,
    socketTimeout: 30000,
    quiet: true,
    noWarnings: true,
    output: `${base}.%(ext)s`
  };
  const ffmpeg = resolveFfmpegPath();
  if (ffmpeg && ffmpeg !== "ffmpeg") options.ffmpegLocation = ffmpeg;
  if (mode === "audio") {
    options.format = "bestaudio/best";
    options.extractAudio = true;
    options.audioFormat = "mp3";
    options.audioQuality = "5";
  } else {
    options.format = "bv*[ext=mp4][height<=720]+ba[ext=m4a]/b[ext=mp4][height<=720]/b[height<=720]";
    options.mergeOutputFormat = "mp4";
  }
  try {
    await ytDlp(url, options);
    const files = fs.readdirSync(os.tmpdir()).filter(file => file.startsWith(path.basename(base) + "."));
    if (!files.length) throw new Error("yt-dlp returned no media file");
    const file = path.join(os.tmpdir(), files[0]);
    const buffer = fs.readFileSync(file);
    const limit = mode === "audio" ? MAX_AUDIO_BYTES : MAX_VIDEO_BYTES;
    if (!buffer.length || buffer.length > limit) throw new Error(`The ${mode} file is too large to send`);
    return { buffer, title: safeName(title, mode), fileName: `${safeName(title, mode)}.${mode === "audio" ? "mp3" : "mp4"}` };
  } finally {
    for (const file of fs.readdirSync(os.tmpdir()).filter(item => item.startsWith(path.basename(base) + "."))) {
      try { fs.unlinkSync(path.join(os.tmpdir(), file)); } catch {}
    }
  }
}

async function downloadRemoteAudio(url, title = "audio", timeoutMs = 60000) {
  if (!/^https?:\/\//i.test(String(url || ""))) throw new Error("Invalid audio URL");
  const response = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: timeoutMs,
    maxContentLength: MAX_AUDIO_BYTES,
    maxBodyLength: MAX_AUDIO_BYTES,
    headers: {
      Accept: "audio/mpeg,audio/*;q=0.9,*/*;q=0.5",
      "User-Agent": "TALKLESS-XMD/4.0"
    }
  });
  const source = Buffer.from(response.data || []);
  if (!source.length || source.length > MAX_AUDIO_BYTES) throw new Error("Remote audio is empty or too large");
  const contentType = String(response.headers?.["content-type"] || "").toLowerCase();
  if (contentType.includes("audio/mpeg") || /\.mp3(?:$|[?#])/i.test(url)) {
    return { buffer: source, title: safeName(title, "audio"), fileName: `${safeName(title, "audio")}.mp3` };
  }
  const base = path.join(os.tmpdir(), `talkless-remote-${crypto.randomBytes(8).toString("hex")}`);
  const input = `${base}.input`;
  const output = `${base}.mp3`;
  fs.writeFileSync(input, source);
  try {
    const ffmpeg = resolveFfmpegPath() || "ffmpeg";
    await execFileAsync(ffmpeg, ["-y", "-i", input, "-vn", "-acodec", "libmp3lame", "-b:a", "128k", output], { timeout: 60000 });
    const buffer = fs.readFileSync(output);
    if (!buffer.length || buffer.length > MAX_AUDIO_BYTES) throw new Error("Converted audio is too large to send");
    return { buffer, title: safeName(title, "audio"), fileName: `${safeName(title, "audio")}.mp3` };
  } finally {
    for (const file of [input, output]) { try { fs.unlinkSync(file); } catch {} }
  }
}

async function downloadRemoteVideo(url, title = "video", timeoutMs = 90000) {
  if (!/^https?:\/\//i.test(String(url || ""))) throw new Error("Invalid video URL");
  const response = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: timeoutMs,
    maxContentLength: MAX_VIDEO_BYTES,
    maxBodyLength: MAX_VIDEO_BYTES,
    headers: {
      Accept: "video/mp4,video/*;q=0.9,*/*;q=0.5",
      "User-Agent": "TALKLESS-XMD/4.0"
    }
  });
  const buffer = Buffer.from(response.data || []);
  const contentType = String(response.headers?.["content-type"] || "").toLowerCase();
  if (!buffer.length || buffer.length > MAX_VIDEO_BYTES || (!contentType.includes("video") && !contentType.includes("mp4"))) {
    throw new Error("Remote video is empty, invalid, or too large");
  }
  return { buffer, title: safeName(title, "video"), fileName: `${safeName(title, "video")}.mp4` };
}

module.exports = { downloadYoutube, downloadRemoteAudio, downloadRemoteVideo, resolveYtDlpBinary };
