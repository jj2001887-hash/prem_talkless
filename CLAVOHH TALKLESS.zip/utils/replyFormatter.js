'use strict';

const BORDER_CHARS = "┏┓┗┛╭╮╰╯┌┐└┘┃│━─═╴╶╼╾";
const BORDER_ONLY = new RegExp("^[\\s" + BORDER_CHARS + "]+$");

function formatCommandReply(value) {
  if (typeof value !== "string") {
    return value;
  }

  const formatted = value
    .replace(/\r\n?/g, "\n")
    .split("\n")
    .map(line => line
      .replace(/^\s*[┃│]\s?/, "")
      .replace(/\s*[┃│]\s*$/, "")
      .replace(/^[┏╭┌]+\s*/, "")
      .replace(/\s*[┗╯┘]+\s*$/, "")
      .replace(/^[━─═]+\s*/, "")
      .replace(/\s*[━─═]+\s*$/, "")
      .trimEnd())
    .filter(line => !BORDER_ONLY.test(line))
    .filter(line => !/^\s*>?\s*(?:powered by|engineered by)\b/i.test(line))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  if (!formatted || formatted.includes("> BY TALKLESS")) {
    return formatted;
  }
  return formatted + "\n\n> BY TALKLESS";
}

module.exports = formatCommandReply;
