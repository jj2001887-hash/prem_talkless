"use strict";

// Shared helpers that make search/download commands respond quickly:
// short timeouts, parallel provider racing, result caching and in-flight de-duplication.

function withTimeout(promise, ms, label = "operation") {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(label + " timed out after " + ms + "ms")), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

function createTtlCache({ ttlMs = 600000, maxEntries = 100, maxBytes = 0 } = {}) {
  const map = new Map();
  let bytes = 0;
  const sizeOf = value => (maxBytes && value && value.buffer && value.buffer.length) || 0;
  function drop(key) {
    const entry = map.get(key);
    if (entry) {
      bytes -= entry.size;
      map.delete(key);
    }
  }
  return {
    get(key) {
      const entry = map.get(key);
      if (!entry) return undefined;
      if (entry.expires < Date.now()) {
        drop(key);
        return undefined;
      }
      map.delete(key);
      map.set(key, entry);
      return entry.value;
    },
    set(key, value) {
      drop(key);
      const size = sizeOf(value);
      if (maxBytes && size > maxBytes) return;
      map.set(key, { value, expires: Date.now() + ttlMs, size });
      bytes += size;
      while (map.size > maxEntries || (maxBytes && bytes > maxBytes)) {
        drop(map.keys().next().value);
      }
    },
    get size() {
      return map.size;
    }
  };
}

const inflight = new Map();
// Concurrent identical requests share one promise.
function dedupe(key, factory) {
  if (inflight.has(key)) return inflight.get(key);
  const promise = Promise.resolve().then(factory).finally(() => inflight.delete(key));
  inflight.set(key, promise);
  return promise;
}

// Resolves with the first provider that succeeds; rejects only if all fail.
async function firstSuccess(factories) {
  const attempts = factories.map(factory => Promise.resolve().then(factory));
  try {
    return await Promise.any(attempts);
  } catch (error) {
    const errors = error.errors || [];
    throw errors[errors.length - 1] || error;
  }
}

function youtubeId(value) {
  return String(value || "").match(/(?:youtu\.be\/|[?&]v=|shorts\/|embed\/|music\.youtube\.com\/watch\?v=)([A-Za-z0-9_-]{11})/)?.[1] || null;
}

module.exports = { withTimeout, createTtlCache, dedupe, firstSuccess, youtubeId };
