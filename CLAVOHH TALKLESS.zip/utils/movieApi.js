"use strict";

const axios = require("axios");
const yts = require("yt-search");

const client = axios.create({
  timeout: 20000,
  headers: { "User-Agent": "TALKLESS-XMD/4.0", Accept: "application/json" }
});

function cleanUrl(value) {
  if (typeof value !== "string" || !/^https?:\/\//i.test(value)) return null;
  return value;
}

function tmdbHeaders() {
  const token = String(process.env.TMDB_READ_TOKEN || "").trim();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function tmdbImage(path) {
  return path ? `https://image.tmdb.org/t/p/w780${path}` : null;
}

function mapTmdbMovie(item) {
  return {
    id: item.id,
    type: "movie",
    title: item.title || item.name || "Untitled",
    year: String(item.release_date || item.first_air_date || "").slice(0, 4),
    rating: item.vote_average ? Number(item.vote_average).toFixed(1) : "N/A",
    overview: item.overview || "No overview available.",
    image: tmdbImage(item.poster_path || item.backdrop_path),
    url: `https://www.themoviedb.org/movie/${item.id}`
  };
}

function mapTmdbShow(item) {
  return {
    id: item.id,
    type: "tv",
    title: item.name || item.title || "Untitled",
    year: String(item.first_air_date || item.release_date || "").slice(0, 4),
    rating: item.vote_average ? Number(item.vote_average).toFixed(1) : "N/A",
    overview: item.overview || "No overview available.",
    image: tmdbImage(item.poster_path || item.backdrop_path),
    url: `https://www.themoviedb.org/tv/${item.id}`
  };
}

async function tmdb(path, params = {}) {
  const headers = tmdbHeaders();
  const apiKey = String(process.env.TMDB_API_KEY || "").trim();
  if (!headers.Authorization && !apiKey) throw new Error("TMDB API key is not configured");
  const requestParams = apiKey && !headers.Authorization ? { ...params, api_key: apiKey } : params;
  const response = await client.get(`https://api.themoviedb.org/3${path}`, { headers, params: requestParams });
  return response.data;
}

async function searchMovies(query, page = 1) {
  const text = String(query || "").trim();
  if (!text) throw new Error("A movie title is required");
  try {
    const data = await tmdb("/search/movie", { query: text, page, include_adult: false });
    return (data.results || []).map(mapTmdbMovie);
  } catch (tmdbError) {
    try {
      const data = (await client.get(`https://v3.sg.media-imdb.com/suggestion/x/${encodeURIComponent(text)}.json`)).data;
      const results = (data.d || []).filter(item => item.id?.startsWith("tt")).slice(0, 10);
      if (results.length) return results.map(item => ({
        id: item.id,
        type: "movie",
        title: item.l || "Untitled",
        year: item.y || "Unknown",
        rating: "N/A",
        overview: "Open the IMDb page for full details.",
        image: cleanUrl(item.i?.imageUrl),
        url: `https://www.imdb.com/title/${item.id}/`
      }));
    } catch (imdbError) {
      throw tmdbError;
    }
    throw new Error("No movie results found. Configure TMDB_API_KEY for full movie metadata.");
  }
}

async function trendingMovies(page = 1) {
  try {
    const data = await tmdb("/trending/movie/week", { page });
    return (data.results || []).map(mapTmdbMovie);
  } catch (error) {
    return searchMovies("popular movies", page);
  }
}

async function movieDetails(idOrQuery) {
  const value = String(idOrQuery || "").trim();
  const tmdbId = value.match(/^(?:tmdb:)?(\d+)$/i)?.[1];
  if (tmdbId && (process.env.TMDB_READ_TOKEN || process.env.TMDB_API_KEY)) {
    return mapTmdbMovie(await tmdb(`/movie/${tmdbId}`, { append_to_response: "videos,credits" }));
  }
  const result = (await searchMovies(value.replace(/^tmdb:/i, ""), 1))[0];
  if (!result) throw new Error("Movie not found");
  return result;
}

async function movieWatchOptions(idOrQuery, region = "US") {
  const movie = await movieDetails(idOrQuery);
  if (!movie.id || !tmdbHeaders().Authorization && !process.env.TMDB_API_KEY) {
    return {
      movie,
      link: movie.url,
      free: [],
      flatrate: [],
      rent: [],
      buy: []
    };
  }
  try {
    const data = await tmdb(`/movie/${movie.id}/watch/providers`);
    const providers = data.results?.[String(region).toUpperCase()] || data.results?.US || {};
    const map = items => (items || []).map(item => item.provider_name).filter(Boolean);
    return {
      movie,
      link: providers.link || movie.url,
      free: map(providers.free),
      flatrate: map(providers.flatrate),
      rent: map(providers.rent),
      buy: map(providers.buy)
    };
  } catch {
    return { movie, link: movie.url, free: [], flatrate: [], rent: [], buy: [] };
  }
}

async function searchShows(query) {
  const text = String(query || "").trim();
  if (!text) throw new Error("A show title is required");
  try {
    const data = await tmdb("/search/tv", { query: text, page: 1 });
    return (data.results || []).map(mapTmdbShow);
  } catch (tmdbError) {
    const data = (await client.get("https://api.tvmaze.com/search/shows", { params: { q: text } })).data;
    if (!Array.isArray(data) || !data.length) throw tmdbError;
    return data.slice(0, 10).map(item => ({
      id: item.show.id,
      type: "tv",
      title: item.show.name,
      year: String(item.show.premiered || "").slice(0, 4),
      rating: item.show.rating?.average || "N/A",
      overview: String(item.show.summary || "No overview available.").replace(/<[^>]+>/g, ""),
      image: cleanUrl(item.show.image?.original || item.show.image?.medium),
      url: item.show.url
    }));
  }
}

async function officialVideoSearch(query, kind = "trailer") {
  const text = `${String(query || "").trim()} official ${kind}`.trim();
  if (!text) throw new Error("A title is required");
  const data = await yts(text);
  return (data.videos || []).slice(0, 5).map(item => ({
    title: item.title,
    author: item.author?.name || "YouTube",
    duration: item.timestamp || "Unknown",
    thumbnail: item.thumbnail,
    url: item.url
  }));
}

function formatResults(results, heading) {
  if (!results.length) return `🔎 *${heading}*\n\nNo results found.\n\n> BY TALKLESS`;
  return `🔎 *${heading}*\n\n` + results.map((item, index) => [
    `${index + 1}. *${item.title}*${item.year ? ` (${item.year})` : ""}`,
    `⭐ ${item.rating || "N/A"}`,
    item.url ? `🔗 ${item.url}` : ""
  ].filter(Boolean).join("\n")).join("\n\n") + "\n\n> BY TALKLESS";
}

function formatDetails(item, heading = "Movie details") {
  return `🎬 *${item.title}*\n\n` +
    `📅 Year: ${item.year || "Unknown"}\n` +
    `⭐ Rating: ${item.rating || "N/A"}\n\n` +
    `📝 ${String(item.overview || "No overview available.").replace(/\s+/g, " ").slice(0, 700)}\n\n` +
    (item.url ? `🔗 ${item.url}\n\n` : "") +
    `> BY TALKLESS`;
}

function formatWatchOptions(options) {
  const lines = [`📺 *Where to watch: ${options.movie.title}*`, ""];
  const add = (label, values) => {
    if (values?.length) lines.push(`${label}: ${values.join(", ")}`);
  };
  add("🆓 Free", options.free);
  add("📡 Streaming", options.flatrate);
  add("💳 Rent", options.rent);
  add("🛒 Buy", options.buy);
  if (lines.length === 2) lines.push("No provider list was available for this region.");
  if (options.link) lines.push("", `🔗 Official providers: ${options.link}`);
  lines.push("", "> BY TALKLESS");
  return lines.join("\n");
}

module.exports = {
  searchMovies,
  trendingMovies,
  movieDetails,
  movieWatchOptions,
  searchShows,
  officialVideoSearch,
  formatResults,
  formatDetails,
  formatWatchOptions
};
